# Results

This section reports various analyses of the recordings obtained. The analyses include the effect of sentence type (declarative vs. interrogative, garden path vs. non-garden path) on the location of prosodic breaks, as well as "study" or inter-reading time (IRT). In order to evaluate the extent to which participants followed the instruction to read immediately for reading 1 and then study the sentence for reading 2, the amount of time that a sentence is displayed before a participant begins to read it (delay) is also discussed and compared across reading 1 vs. reading 2.

## Participants in the reported analyses

There is a total of 32 participants included, 48 total items, 16 of which are experimental items, with each item read twice by each participant. The 32 filler items are not included in analyses except where specified. The same recordings are used for all analyses.





<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:vtab)No. of participants per version-order combination</caption>
 <thead>
<tr>
<th style="border-bottom:hidden" colspan="1"></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Order</div></th>
<th style="border-bottom:hidden" colspan="1"></th>
</tr>
  <tr>
   <th style="text-align:left;">   </th>
   <th style="text-align:center;"> 1 </th>
   <th style="text-align:center;"> 2 </th>
   <th style="text-align:center;"> Sum </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> Version 1 </td>
   <td style="text-align:center;"> 5 </td>
   <td style="text-align:center;"> 4 </td>
   <td style="text-align:center;"> 9 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Version 2 </td>
   <td style="text-align:center;"> 4 </td>
   <td style="text-align:center;"> 4 </td>
   <td style="text-align:center;"> 8 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Version 3 </td>
   <td style="text-align:center;"> 4 </td>
   <td style="text-align:center;"> 4 </td>
   <td style="text-align:center;"> 8 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Version 4 </td>
   <td style="text-align:center;"> 2 </td>
   <td style="text-align:center;"> 5 </td>
   <td style="text-align:center;"> 7 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Sum </td>
   <td style="text-align:center;"> 15 </td>
   <td style="text-align:center;"> 17 </td>
   <td style="text-align:center;"> 32 </td>
  </tr>
</tbody>
</table>

There were 4 versions of the experiment, and two possible orderings, with approximately equal number of participants for each version-order combination. Ideally there would be 4 participants per version-order combination, but due to participant attrition and issues during data collection, the distribution is as in Table \ref{tab:vtab}.

Some items are missing due to technical issues during data collection. Data are also excluded if either recording from a pair of recordings (reading 1 or reading 2) is missing (there were 9 incomplete pairs excluded) because without the other member, it is difficult to determine the extent to which the participant followed instructions (i.e. did not study the sentence before reading 1, did study the sentence before reading 2). Recordings with no reported breaks are excluded from the prosodic analyses, since they are unlikely to represent the reader's intended prosodic structure (there were 5 such recordings). The paired readings of these are not excluded, and IRTs extracted from them are included in the timing analyses, since delay information is available for both readings. Ultimately, 978 experimental item recordings are analyzed (489 pairs). The distribution of these recordings across the experimental item versions is shown in table \ref{tab:totByCond}.

<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:totByCond)Number of recordings by condition</caption>
 <thead>
  <tr>
   <th style="text-align:left;">   </th>
   <th style="text-align:right;"> D </th>
   <th style="text-align:right;"> Q </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> -GP </td>
   <td style="text-align:right;"> 246 </td>
   <td style="text-align:right;"> 247 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> +GP </td>
   <td style="text-align:right;"> 245 </td>
   <td style="text-align:right;"> 240 </td>
  </tr>
</tbody>
</table>

If every items for each of the 32 participants had been available and included, the expected number per bin would be 256[^n].

## Prosody {#results-prosody}

This subsection presents the results of the independent rater's judgements regarding prosodic boundaries.

[^n]: There are 32 participants, 16 items, and 2 readings, divided across 4 bins.

The sentences can be informally broken into regions as in (@structure).

  (@structure) [~SUBJ~ She] [~VERBS~ had intended to set] [~OBJ~ the clothes] ~OBJ~ [~PP1~ in the hamper] ~PP1~ [~PP2~ onto the dresser].

In what follows, I will discuss prosodic breaks at the points directly after the direct object (referred to as OBJ) and directly after PP1 (referred to as PP1).

#### Breaks after PP1 and direct object

Because "natural prosody" is likely to be less often produced in Reading 1 than in a Reading 2, it's important to consider the prosodic patterns for the two readings independently. 



The prevalence of PP1 breaks for each condition in Reading 1 and Reading 2 recordings is described in table \ref{tab:pp1}.

<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:pp1)PP1 break by condition and reading</caption>
 <thead>
<tr>
<th style="border-bottom:hidden" colspan="1"></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Reading 1</div></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Reading 2</div></th>
</tr>
  <tr>
   <th style="text-align:left;">  </th>
   <th style="text-align:left;"> D </th>
   <th style="text-align:left;"> Q </th>
   <th style="text-align:left;"> D </th>
   <th style="text-align:left;"> Q </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> -GP </td>
   <td style="text-align:left;"> 84 (68.3%) </td>
   <td style="text-align:left;"> 84 (68.3%) </td>
   <td style="text-align:left;"> 84 (68.3%) </td>
   <td style="text-align:left;"> 83 (66.9%) </td>
  </tr>
  <tr>
   <td style="text-align:left;"> +GP </td>
   <td style="text-align:left;"> 122 (99.2%) </td>
   <td style="text-align:left;"> 119 (99.2%) </td>
   <td style="text-align:left;"> 121 (99.2%) </td>
   <td style="text-align:left;"> 117 (97.5%) </td>
  </tr>
</tbody>
</table>


<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:obj)OBJ break by condition and reading</caption>
 <thead>
<tr>
<th style="border-bottom:hidden" colspan="1"></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Reading 1</div></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Reading 2</div></th>
</tr>
  <tr>
   <th style="text-align:left;">  </th>
   <th style="text-align:left;"> D </th>
   <th style="text-align:left;"> Q </th>
   <th style="text-align:left;"> D </th>
   <th style="text-align:left;"> Q </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> -GP </td>
   <td style="text-align:left;"> 95 (77.2%) </td>
   <td style="text-align:left;"> 94 (76.4%) </td>
   <td style="text-align:left;"> 104 (84.6%) </td>
   <td style="text-align:left;"> 90 (72.6%) </td>
  </tr>
  <tr>
   <td style="text-align:left;"> +GP </td>
   <td style="text-align:left;"> 71 (57.7%) </td>
   <td style="text-align:left;"> 68 (56.7%) </td>
   <td style="text-align:left;"> 89 (73.0%) </td>
   <td style="text-align:left;"> 89 (74.2%) </td>
  </tr>
</tbody>
</table>

The primary difference across Readings is in the OBJ break distribution. 

#### PP1 and object breaks combined

It is perhaps more interesting to look at the combined distribution of the breaks: i.e., a sentence can have one of four patterns: OBJ and PP1 breaks are present; only OBJ or only PP1 is present; or neither is present. As mentioned earlier, there were only 5 cases where neither are present, and those are excluded.



<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:combobreaksBycond)Breaks (%) by condition</caption>
 <thead>
<tr>
<th style="border-bottom:hidden" colspan="1"></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="4"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Reading 1</div></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="4"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Reading 2</div></th>
</tr>
<tr>
<th style="border-bottom:hidden" colspan="1"></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Non-garden path</div></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Garden path</div></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Non-garden path</div></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Garden path</div></th>
</tr>
  <tr>
   <th style="text-align:left;">   </th>
   <th style="text-align:center;"> D </th>
   <th style="text-align:center;"> Q </th>
   <th style="text-align:center;"> D </th>
   <th style="text-align:center;"> Q </th>
   <th style="text-align:center;"> D </th>
   <th style="text-align:center;"> Q </th>
   <th style="text-align:center;"> D </th>
   <th style="text-align:center;"> Q </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;font-weight: bold;"> Both </td>
   <td style="text-align:center;"> 54.1 </td>
   <td style="text-align:center;"> 43.0 </td>
   <td style="text-align:center;"> 72.1 </td>
   <td style="text-align:center;"> 71.7 </td>
   <td style="text-align:center;"> 54.1 </td>
   <td style="text-align:center;"> 43.0 </td>
   <td style="text-align:center;"> 72.1 </td>
   <td style="text-align:center;"> 71.7 </td>
  </tr>
  <tr>
   <td style="text-align:left;font-weight: bold;"> OBJ only </td>
   <td style="text-align:center;"> 31.1 </td>
   <td style="text-align:center;"> 31.4 </td>
   <td style="text-align:center;"> 0.8 </td>
   <td style="text-align:center;"> 2.5 </td>
   <td style="text-align:center;"> 31.1 </td>
   <td style="text-align:center;"> 31.4 </td>
   <td style="text-align:center;"> 0.8 </td>
   <td style="text-align:center;"> 2.5 </td>
  </tr>
  <tr>
   <td style="text-align:left;font-weight: bold;"> PP1 only </td>
   <td style="text-align:center;"> 14.8 </td>
   <td style="text-align:center;"> 25.6 </td>
   <td style="text-align:center;"> 27.0 </td>
   <td style="text-align:center;"> 25.8 </td>
   <td style="text-align:center;"> 14.8 </td>
   <td style="text-align:center;"> 25.6 </td>
   <td style="text-align:center;"> 27.0 </td>
   <td style="text-align:center;"> 25.8 </td>
  </tr>
</tbody>
</table>

Table \ref{tab:combobreaksBycond} shows that for +GP sentences, there are very few instances with the OBJ-only pattern (0.8% in declaratives, 2.5% in interrogatives); whereas that pattern is fairly robust for -GP sentences (31.1% in declaratives, 31.4% in interrogatives). The pattern with both breaks is somewhat more common for +GP sentences (72.1% in declaratives, 71.7% in interrogatives) than -GP (54.1% in declaratives, 43.0% in interrogatives). The PP1-only pattern occurs at about the same rate in +GP interrogatives (25.8%) as in -GP interrogatives (25.6%) and +GP declaratives (27%), but is noticeably less common for -GP declaratives (14.8%).

<!--
todo
consider moving R1 delay analysis here
-->

#### PP1 and object breaks and their relative prominence

Table \ref{tab:pros2lvl} presents data similar to those in the previous section, but it incorporates the rater's judgement of the relative prominence of the breaks. The &gt; symbol indicates that the rater found the break on the left of that symbol to be stronger, or more prominent, than the break on the left. When no symbol is shown between the two breaks, the rather found them to be of equal prominence. Please be aware that inter-rater reliability for relative prominence was not good, as discussed in section \ref{sec:raterRel}.

<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:pros2lvlPre)Prosodic pattern type by condition and reading</caption>
 <thead>
<tr>
<th style="border-bottom:hidden" colspan="1"></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="4"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Reading 1</div></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="4"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Reading 2</div></th>
</tr>
  <tr>
   <th style="text-align:center;"> Pattern </th>
   <th style="text-align:center;"> D -GP </th>
   <th style="text-align:center;"> D +GP </th>
   <th style="text-align:center;"> Q -GP </th>
   <th style="text-align:center;"> Q +GP </th>
   <th style="text-align:center;"> D -GP </th>
   <th style="text-align:center;"> D +GP </th>
   <th style="text-align:center;"> Q -GP </th>
   <th style="text-align:center;"> Q +GP </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:center;"> OBJ </td>
   <td style="text-align:center;"> 31.1 </td>
   <td style="text-align:center;"> 0.8 </td>
   <td style="text-align:center;"> 30.6 </td>
   <td style="text-align:center;border-right:1px solid;"> 2.5 </td>
   <td style="text-align:center;"> 31.1 </td>
   <td style="text-align:center;"> 0.8 </td>
   <td style="text-align:center;"> 30.6 </td>
   <td style="text-align:center;"> 2.5 </td>
  </tr>
  <tr>
   <td style="text-align:center;"> OBJ &gt; PP1 </td>
   <td style="text-align:center;"> 32.0 </td>
   <td style="text-align:center;"> 23.0 </td>
   <td style="text-align:center;"> 29.8 </td>
   <td style="text-align:center;border-right:1px solid;"> 14.2 </td>
   <td style="text-align:center;"> 32.0 </td>
   <td style="text-align:center;"> 23.0 </td>
   <td style="text-align:center;"> 29.8 </td>
   <td style="text-align:center;"> 14.2 </td>
  </tr>
  <tr>
   <td style="text-align:center;"> OBJ PP1 </td>
   <td style="text-align:center;"> 5.7 </td>
   <td style="text-align:center;"> 3.3 </td>
   <td style="text-align:center;"> 1.7 </td>
   <td style="text-align:center;border-right:1px solid;"> 4.2 </td>
   <td style="text-align:center;"> 5.7 </td>
   <td style="text-align:center;"> 3.3 </td>
   <td style="text-align:center;"> 1.7 </td>
   <td style="text-align:center;"> 4.2 </td>
  </tr>
  <tr>
   <td style="text-align:center;"> PP1 &gt; OBJ </td>
   <td style="text-align:center;"> 16.4 </td>
   <td style="text-align:center;"> 46.7 </td>
   <td style="text-align:center;"> 13.2 </td>
   <td style="text-align:center;border-right:1px solid;"> 53.3 </td>
   <td style="text-align:center;"> 16.4 </td>
   <td style="text-align:center;"> 46.7 </td>
   <td style="text-align:center;"> 13.2 </td>
   <td style="text-align:center;"> 53.3 </td>
  </tr>
  <tr>
   <td style="text-align:center;"> PP1 </td>
   <td style="text-align:center;"> 14.8 </td>
   <td style="text-align:center;"> 26.2 </td>
   <td style="text-align:center;"> 24.8 </td>
   <td style="text-align:center;border-right:1px solid;"> 25.8 </td>
   <td style="text-align:center;"> 14.8 </td>
   <td style="text-align:center;"> 26.2 </td>
   <td style="text-align:center;"> 24.8 </td>
   <td style="text-align:center;"> 25.8 </td>
  </tr>
</tbody>
</table>

Another way of looking at these same data is to think of a recording as being PP1-dominant (i.e., PP1 is the only or the strongest break), OBJ-dominate, or neither. This categorization is useful because it creates binary outcomes that can be subjected to logistic regression analyses. The frequency of these patterns is reported in table \ref{tab:domtab}.

<!-- 

todo 

  * split dom tables into OBJ tables and PP1 table?

-->



<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:domtab)Break dominance (%) by condition</caption>
 <thead>
<tr>
<th style="border-bottom:hidden" colspan="1"></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="4"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">PP1</div></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="4"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">OBJ</div></th>
</tr>
<tr>
<th style="border-bottom:hidden" colspan="1"></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Reading 1</div></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Reading 2</div></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Reading 1</div></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Reading 2</div></th>
</tr>
  <tr>
   <th style="text-align:left;">   </th>
   <th style="text-align:center;"> Not dominant </th>
   <th style="text-align:center;"> Dominant </th>
   <th style="text-align:center;"> Not dominant </th>
   <th style="text-align:center;"> Dominant </th>
   <th style="text-align:center;"> Not dominant </th>
   <th style="text-align:center;"> Dominant </th>
   <th style="text-align:center;"> Not dominant </th>
   <th style="text-align:center;"> Dominant </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> D -GP </td>
   <td style="text-align:center;"> 59.3 </td>
   <td style="text-align:center;"> 40.7 </td>
   <td style="text-align:center;"> 69.1 </td>
   <td style="text-align:center;border-right:1px solid;"> 30.9 </td>
   <td style="text-align:center;"> 43.9 </td>
   <td style="text-align:center;"> 56.1 </td>
   <td style="text-align:center;"> 37.4 </td>
   <td style="text-align:center;"> 62.6 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> D +GP </td>
   <td style="text-align:center;"> 21.1 </td>
   <td style="text-align:center;"> 78.9 </td>
   <td style="text-align:center;"> 27.0 </td>
   <td style="text-align:center;border-right:1px solid;"> 73.0 </td>
   <td style="text-align:center;"> 85.4 </td>
   <td style="text-align:center;"> 14.6 </td>
   <td style="text-align:center;"> 76.2 </td>
   <td style="text-align:center;"> 23.8 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Q -GP </td>
   <td style="text-align:center;"> 59.3 </td>
   <td style="text-align:center;"> 40.7 </td>
   <td style="text-align:center;"> 62.9 </td>
   <td style="text-align:center;border-right:1px solid;"> 37.1 </td>
   <td style="text-align:center;"> 44.7 </td>
   <td style="text-align:center;"> 55.3 </td>
   <td style="text-align:center;"> 41.1 </td>
   <td style="text-align:center;"> 58.9 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Q +GP </td>
   <td style="text-align:center;"> 12.5 </td>
   <td style="text-align:center;"> 87.5 </td>
   <td style="text-align:center;"> 20.8 </td>
   <td style="text-align:center;border-right:1px solid;"> 79.2 </td>
   <td style="text-align:center;"> 89.2 </td>
   <td style="text-align:center;"> 10.8 </td>
   <td style="text-align:center;"> 83.3 </td>
   <td style="text-align:center;"> 16.7 </td>
  </tr>
</tbody>
</table>

\clearpage

### Regression models predicting break occurence

Models predicting the PP1 break and the object break are presented in table \ref{tab:lmPros}. No random slopes were included, as models with random slopes did not converge. For all models in this section, the intercept represents the declarative, non-garden path case. Where Reading is included as a factor, the intercept represents Reading 1.







<!--html_preserve--><table class="huxtable" style="border-collapse: collapse; margin-bottom: 2em; margin-top: 2em; width: 50%; margin-left: auto; margin-right: auto;  " id="lmPros">
<caption style="caption-side: top; text-align: center;">(#tab:lmPros) Logistic regression models of prosody</caption><col><col><col><col><col><tr>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0pt 0pt; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">PP1</td>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">OBJ</td>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">PP1 Dominance</td>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">OBJ Dominance</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">Intercept</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">1.102 *&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">0.934 *&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-0.098&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-0.111&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.448)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.384)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.336)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.333)&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">GP</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">4.528 ***</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-1.004 ***</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">2.035 ***</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-2.104 ***</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.737)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.232)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.222)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.229)&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">Q</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-0.044&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-0.384&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">0.138&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-0.091&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.216)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.238)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.202)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.198)&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">GP:Q Interaction</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-0.687&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">0.417&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">0.391&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-0.358&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.898)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.321)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.316)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.327)&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">Reading</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-0.081&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">0.559 ***</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-0.399 **&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">0.374 *&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">(0.208)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">(0.160)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">(0.155)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">(0.157)&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">N</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">978&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">978&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">978&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">978&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">logLik</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-310.339&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-511.709&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-534.478&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-520.813&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">AIC</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">634.678&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">1037.418&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">1082.956&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">1055.627&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td colspan="5" style="vertical-align: top; text-align: left; white-space: normal; padding: 4pt 4pt 4pt 4pt;"> *** p &lt; 0.001;  ** p &lt; 0.01;  * p &lt; 0.05.</td>
</tr>
</table>
<!--/html_preserve-->

Reading is a statistically siginficant predictor for three of the four models shown in table \ref{tab:bothprosmodels}. Models which exclude Reading 1 are shown in \ref{tab:prosmodels}, as these data are more likely to represent true prosodic breaks, or the intended prosody of the reader, rather than mistakes or hesitations. For the models over only Reading 2, the one predicting the presence of a PP1 break failed to converge.

<!--html_preserve--><table class="huxtable" style="border-collapse: collapse; margin-bottom: 2em; margin-top: 2em; width: 50%; margin-left: auto; margin-right: auto;  " id="lmPros">
<caption style="caption-side: top; text-align: center;">(#tab:lmPros) Logistic regression models of prosody, Reading 2 only</caption><col><col><col><col><tr>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0pt 0pt; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">OBJ</td>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">PP1 Dominance</td>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">OBJ Dominance</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">Intercept</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">2.196 ***</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-0.947 **&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">0.595 *&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.413)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.288)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.258)&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">GP</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-0.885 *&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">2.113 ***</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-1.922 ***</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.355)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.317)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.311)&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">Q</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-0.877 *&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">0.313&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-0.174&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.352)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.292)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(0.279)&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">GP:Q Interaction</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">0.965 *&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">0.087&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-0.324&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">(0.481)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">(0.435)&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">(0.440)&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">N</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">489&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">489&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">489&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">logLik</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-240.448&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-279.219&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-278.314&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">AIC</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">492.896&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">570.438&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">568.628&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td colspan="4" style="vertical-align: top; text-align: left; white-space: normal; padding: 4pt 4pt 4pt 4pt;"> *** p &lt; 0.001;  ** p &lt; 0.01;  * p &lt; 0.05.</td>
</tr>
</table>
<!--/html_preserve-->

Note that the model predicting the presence of the PP1 break failed to converg, and so is omitted from the Reading 2 only models.
```
TODO 

Models that exclude the interaction term and that exclude Q vs D as predictor
```
\clearpage

## Inter-reading time (IRT) {#results-irt}

This document examines the inter-reading time (IRT) from the study. IRT was measured over 489 recordings: 32 participants, 48 items = 0 recording pairs (reading 1 and reading 2), with -489 missing pairs. The missing data are a result of one or both recordings from a pair being unusable due to technical issues (e.g. a failure of recording equipment, or participant error).

#### Distribution of IRT and data clean-up {#irtDis}

The raw IRTs for experimental items, before any outliers are trimmed, are distributed as in figure \ref{fig:rawIRThist}. Overall mean IRT of these data (n = 1494), is 6.5s. The longest is 24.5s and the shortest 429ms. Median IRT is 5.9s.

<div class="figure">
<img src="4-results_files/figure-html/rawIRThist-1.png" alt="Distribution of raw IRT" width="672" />
<p class="caption">(\#fig:rawIRThist)Distribution of raw IRT</p>
</div>

IRTs below 250ms (2) and above 25s (5) are assumed to be implausible and omitted. Experimental data were then Winsorized by participant to bring data in the 2.5th and 97.5th percentile of data to the value at those tresholds. The resulting measure is referred to as wIRT and is distribued as shown in Figure \ref{fig:wIRT} (n = 489). Overall mean for wIRT is 6.5s. The longest wIRT is 22.2s and the shortest is 709ms. Median wIRT is 6.1s.

<div class="figure">
<img src="4-results_files/figure-html/wIRT-1.png" alt="Distribution of wIRT" width="672" />
<p class="caption">(\#fig:wIRT)Distribution of wIRT</p>
</div>
\clearpage

#### Means by condition

Table \ref{tab:mns} shows the mean wIRT by experimental condition. The top left cell represents the mean wIRT for the declaritive controls ("D -GP"). The bottom row shows the increase in IRT across the garden path condition. 


<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:mns)Means (s) by condition</caption>
 <thead>
  <tr>
   <th style="text-align:left;"> Condition </th>
   <th style="text-align:right;"> D </th>
   <th style="text-align:right;"> Q </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> -GP </td>
   <td style="text-align:right;"> 6.20 </td>
   <td style="text-align:right;"> 6.47 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> +GP </td>
   <td style="text-align:right;"> 6.61 </td>
   <td style="text-align:right;"> 6.85 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Increase </td>
   <td style="text-align:right;"> 0.41 </td>
   <td style="text-align:right;"> 0.37 </td>
  </tr>
</tbody>
</table>

The difference in the effect of &plusmn;GP across &plusmn;Q is 0.04s. That is, the mean amount that IRT increased for a garden path declarative compared to a non-garden path declarative is 0.04s more than the amount that IRT increased for a garden path interrogative compared to a non-garden path interrogative.

<div class="figure">
<img src="4-results_files/figure-html/interactinplot-1.png" alt="Mean IRT by condition" width="672" />
<p class="caption">(\#fig:interactinplot)Mean IRT by condition</p>
</div>

\clearpage

#### Regression models of IRT

The models with random slopes for participant and item did not converge, so the tables in this section show models with no random slopes. 



For the first model, fixed effects of &plusmn;GP and &plusmn;Q as well is the interaction between them were included, along with random effects of participant and item. The second model removes the interaction, but keeps both main effects.

<!--html_preserve--><table class="huxtable" style="border-collapse: collapse; margin-bottom: 2em; margin-top: 2em; width: 50%; margin-left: auto; margin-right: auto;  " id="tab:models">
<caption style="caption-side: top; text-align: center;">(#tab:models) Models</caption><col><col><col><col><col><tr>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0pt 0pt; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">Full</td>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">No interaction</td>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">No random effects</td>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">No fixed effects</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">+GP</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">416.401&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">456.133&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">411.636&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(299.877)</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(212.357)</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(487.484)</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">Q</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">288.168&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">327.554&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">272.462&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(298.528)</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(212.313)</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(485.506)</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">+GP Q</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">79.786&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-36.931&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">(425.161)</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">(690.156)</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">N</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">489&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">489&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">489&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">489&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">logLik</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-4544.769&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-4544.787&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-4724.504&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-4548.229</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">AIC</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">9103.538&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">9101.573&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">9459.008&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">9104.458</td>
</tr>
</table>
<!--/html_preserve-->

A model with no fixed effects and one with no random effects were also run. The estimates from these models can be seen in table \ref{tab:models}. 

\clearpage

Several model comparisons were made, seen in tables \ref{tab:modCom3}, \ref{tab:modCom}, and \ref{tab:modCom2}.

<table>
<caption>(\#tab:modCom3)Full model vs. no fixed effects</caption>
 <thead>
  <tr>
   <th style="text-align:left;">   </th>
   <th style="text-align:right;"> Df </th>
   <th style="text-align:right;"> AIC </th>
   <th style="text-align:right;"> BIC </th>
   <th style="text-align:right;"> logLik </th>
   <th style="text-align:right;"> deviance </th>
   <th style="text-align:right;"> $\chi^2$ </th>
   <th style="text-align:right;"> Df($\chi$) </th>
   <th style="text-align:right;"> Pr(>$\chi^2$) </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> No fixed effects </td>
   <td style="text-align:right;"> 4 </td>
   <td style="text-align:right;"> 9104.458 </td>
   <td style="text-align:right;"> 9121.228 </td>
   <td style="text-align:right;"> -4548.229 </td>
   <td style="text-align:right;"> 9096.458 </td>
   <td style="text-align:right;"> NA </td>
   <td style="text-align:right;"> NA </td>
   <td style="text-align:right;"> NA </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Full </td>
   <td style="text-align:right;"> 7 </td>
   <td style="text-align:right;"> 9103.538 </td>
   <td style="text-align:right;"> 9132.885 </td>
   <td style="text-align:right;"> -4544.769 </td>
   <td style="text-align:right;"> 9089.538 </td>
   <td style="text-align:right;"> 6.920059 </td>
   <td style="text-align:right;"> 3 </td>
   <td style="text-align:right;"> 0.0744899 </td>
  </tr>
</tbody>
</table>

Table \ref{tab:modCom3} shows that the improvement of the full model over the one with with no fixed effects approaches significance (p < 0.1). 

<table>
<caption>(\#tab:modCom)Full model vs. no interaction</caption>
 <thead>
  <tr>
   <th style="text-align:left;">   </th>
   <th style="text-align:right;"> Df </th>
   <th style="text-align:right;"> AIC </th>
   <th style="text-align:right;"> BIC </th>
   <th style="text-align:right;"> logLik </th>
   <th style="text-align:right;"> deviance </th>
   <th style="text-align:right;"> $\chi^2$ </th>
   <th style="text-align:right;"> Df($\chi$) </th>
   <th style="text-align:right;"> Pr(>$\chi^2$) </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> No interaction </td>
   <td style="text-align:right;"> 6 </td>
   <td style="text-align:right;"> 9101.573 </td>
   <td style="text-align:right;"> 9126.728 </td>
   <td style="text-align:right;"> -4544.787 </td>
   <td style="text-align:right;"> 9089.573 </td>
   <td style="text-align:right;"> NA </td>
   <td style="text-align:right;"> NA </td>
   <td style="text-align:right;"> NA </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Full </td>
   <td style="text-align:right;"> 7 </td>
   <td style="text-align:right;"> 9103.538 </td>
   <td style="text-align:right;"> 9132.885 </td>
   <td style="text-align:right;"> -4544.769 </td>
   <td style="text-align:right;"> 9089.538 </td>
   <td style="text-align:right;"> 0.0352051 </td>
   <td style="text-align:right;"> 1 </td>
   <td style="text-align:right;"> 0.8511665 </td>
  </tr>
</tbody>
</table>

The interaction between main effects, though, is not able to be confirmed (in fact, table \ref{tab:modCom} shows the non-interaction to be better, but not to a stastically significance degree).

<table>
<caption>(\#tab:modCom2)Full model vs. no random effects</caption>
 <thead>
  <tr>
   <th style="text-align:left;">   </th>
   <th style="text-align:right;"> Df </th>
   <th style="text-align:right;"> AIC </th>
   <th style="text-align:right;"> BIC </th>
   <th style="text-align:right;"> logLik </th>
   <th style="text-align:right;"> deviance </th>
   <th style="text-align:right;"> $\chi^2$ </th>
   <th style="text-align:right;"> Df($\chi$) </th>
   <th style="text-align:right;"> Pr(>$\chi^2$) </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> No random effects </td>
   <td style="text-align:right;"> 5 </td>
   <td style="text-align:right;"> 9459.008 </td>
   <td style="text-align:right;"> 9479.970 </td>
   <td style="text-align:right;"> -4724.504 </td>
   <td style="text-align:right;"> 9449.008 </td>
   <td style="text-align:right;"> NA </td>
   <td style="text-align:right;"> NA </td>
   <td style="text-align:right;"> NA </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Full </td>
   <td style="text-align:right;"> 7 </td>
   <td style="text-align:right;"> 9103.538 </td>
   <td style="text-align:right;"> 9132.885 </td>
   <td style="text-align:right;"> -4544.769 </td>
   <td style="text-align:right;"> 9089.538 </td>
   <td style="text-align:right;"> 359.4701 </td>
   <td style="text-align:right;"> 2 </td>
   <td style="text-align:right;"> 0 </td>
  </tr>
</tbody>
</table>

Table \ref{tab:modCom2} shows that the random effects of participant and item improve the model in a stastically signifcant way.

\clearpage

#### Effect of verb on IRT

If we consider the mean wIRT by which of the 4 verbs occured in the target sentence (*cram*, *set*, *put*, or *stick*), we see that there was some difference in how the two experimental manipulations (&plusmn;GP = garden path status and &plusmn;Q = interrogative vs. declarative status) effected wIRT. The means (and standard deviation) across the conditions are reported for each verb in table \ref{tab:verbConMeans}.



<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:verbConMeans)Mean (sd) wIRT by condition and verb in seconds</caption>
 <thead>
  <tr>
   <th style="text-align:left;"> Verb </th>
   <th style="text-align:left;"> D -GP </th>
   <th style="text-align:left;"> D +GP </th>
   <th style="text-align:left;"> Q -GP </th>
   <th style="text-align:left;"> Q +GP </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> cram </td>
   <td style="text-align:left;"> 6.4 (3.9) </td>
   <td style="text-align:left;"> 6.9 (4) </td>
   <td style="text-align:left;"> 5.9 (3.1) </td>
   <td style="text-align:left;"> 6.5 (3.8) </td>
  </tr>
  <tr>
   <td style="text-align:left;"> put </td>
   <td style="text-align:left;"> 6.5 (3.8) </td>
   <td style="text-align:left;"> 6.8 (3.7) </td>
   <td style="text-align:left;"> 6 (3.3) </td>
   <td style="text-align:left;"> 7 (5.2) </td>
  </tr>
  <tr>
   <td style="text-align:left;"> set </td>
   <td style="text-align:left;"> 6.1 (3.2) </td>
   <td style="text-align:left;"> 6.3 (3.2) </td>
   <td style="text-align:left;"> 7.4 (4.5) </td>
   <td style="text-align:left;"> 6.6 (3.6) </td>
  </tr>
  <tr>
   <td style="text-align:left;"> stick </td>
   <td style="text-align:left;"> 5.8 (4.2) </td>
   <td style="text-align:left;"> 6.5 (3.2) </td>
   <td style="text-align:left;"> 6.7 (4.1) </td>
   <td style="text-align:left;"> 7.4 (4.2) </td>
  </tr>
</tbody>
</table>

To isolate the effect of the garden path for interrogatives as compared to declartives, we can subtract the mean for declarative non-garden paths from the mean for declarative garden paths, and then do the same for interrogatives. These measures are referred to as the "declarative GP effect" and "interrogative GP effect" in \ref{verbConDiffMeans}. The difference between the declarative GP effect from the interrogative GP effect is labeled the "difference in effect." We can see that for 2 of the 4 verbs (*set* and *stick*), there was a positive difference in effect, while for the other two we find a negative one.

<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:verbConDiffMeans)Effect of GP on wIRT by verb</caption>
 <thead>
  <tr>
   <th style="text-align:left;"> Verb </th>
   <th style="text-align:right;"> Declarative GP effect </th>
   <th style="text-align:right;"> Interrogative GP effect </th>
   <th style="text-align:right;"> Difference in effect </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> cram </td>
   <td style="text-align:right;"> 0.5 </td>
   <td style="text-align:right;"> 0.6 </td>
   <td style="text-align:right;"> -0.1 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> put </td>
   <td style="text-align:right;"> 0.3 </td>
   <td style="text-align:right;"> 1.0 </td>
   <td style="text-align:right;"> -0.8 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> set </td>
   <td style="text-align:right;"> 0.2 </td>
   <td style="text-align:right;"> -0.9 </td>
   <td style="text-align:right;"> 1.0 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> stick </td>
   <td style="text-align:right;"> 0.7 </td>
   <td style="text-align:right;"> 0.7 </td>
   <td style="text-align:right;"> 0.0 </td>
  </tr>
</tbody>
</table>
#### Individual variation in IRT

Individuals vary with regard to the effect of the garden path condition on IRT. For 17 of 32, the increase in IRT for garden paths is greater for interrogatives than it is for declaratives.

<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:pPattern)Mean wIRT (ms) by condition and participant</caption>
 <thead>
  <tr>
   <th style="text-align:left;"> Participant </th>
   <th style="text-align:right;"> D -GP </th>
   <th style="text-align:right;"> D +GP </th>
   <th style="text-align:right;"> Q -GP </th>
   <th style="text-align:right;"> Q +GP </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> 10 </td>
   <td style="text-align:right;"> 9072.500 </td>
   <td style="text-align:right;"> 9416.155 </td>
   <td style="text-align:right;"> 8734.438 </td>
   <td style="text-align:right;"> 9630.157 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 1 </td>
   <td style="text-align:right;"> 2723.095 </td>
   <td style="text-align:right;"> 2764.875 </td>
   <td style="text-align:right;"> 3165.468 </td>
   <td style="text-align:right;"> 3061.438 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 2 </td>
   <td style="text-align:right;"> 6077.595 </td>
   <td style="text-align:right;"> 7088.435 </td>
   <td style="text-align:right;"> 4410.845 </td>
   <td style="text-align:right;"> 6398.435 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 3 </td>
   <td style="text-align:right;"> 5655.472 </td>
   <td style="text-align:right;"> 8400.845 </td>
   <td style="text-align:right;"> 6056.405 </td>
   <td style="text-align:right;"> 7267.347 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 4 </td>
   <td style="text-align:right;"> 7993.717 </td>
   <td style="text-align:right;"> 5457.905 </td>
   <td style="text-align:right;"> 10609.750 </td>
   <td style="text-align:right;"> 7010.720 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 5 </td>
   <td style="text-align:right;"> 13082.620 </td>
   <td style="text-align:right;"> 10694.565 </td>
   <td style="text-align:right;"> 9437.685 </td>
   <td style="text-align:right;"> 12188.125 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 6 </td>
   <td style="text-align:right;"> 12848.093 </td>
   <td style="text-align:right;"> 10828.407 </td>
   <td style="text-align:right;"> 13018.030 </td>
   <td style="text-align:right;"> 14695.872 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 7 </td>
   <td style="text-align:right;"> 5706.287 </td>
   <td style="text-align:right;"> 5864.283 </td>
   <td style="text-align:right;"> 6291.778 </td>
   <td style="text-align:right;"> 4918.595 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 9 </td>
   <td style="text-align:right;"> 6234.815 </td>
   <td style="text-align:right;"> 6632.685 </td>
   <td style="text-align:right;"> 6386.938 </td>
   <td style="text-align:right;"> 6484.312 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 11 </td>
   <td style="text-align:right;"> 8635.833 </td>
   <td style="text-align:right;"> 9030.440 </td>
   <td style="text-align:right;"> 5688.040 </td>
   <td style="text-align:right;"> 12075.837 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 12 </td>
   <td style="text-align:right;"> 5436.092 </td>
   <td style="text-align:right;"> 5236.717 </td>
   <td style="text-align:right;"> 6146.935 </td>
   <td style="text-align:right;"> 7347.062 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 13 </td>
   <td style="text-align:right;"> 10779.875 </td>
   <td style="text-align:right;"> 11638.595 </td>
   <td style="text-align:right;"> 9410.875 </td>
   <td style="text-align:right;"> 10931.093 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 14 </td>
   <td style="text-align:right;"> 7180.315 </td>
   <td style="text-align:right;"> 8851.722 </td>
   <td style="text-align:right;"> 8443.062 </td>
   <td style="text-align:right;"> 12052.435 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 15 </td>
   <td style="text-align:right;"> 9673.310 </td>
   <td style="text-align:right;"> 7771.158 </td>
   <td style="text-align:right;"> 9463.500 </td>
   <td style="text-align:right;"> 5764.438 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 16 </td>
   <td style="text-align:right;"> 12583.907 </td>
   <td style="text-align:right;"> 9725.440 </td>
   <td style="text-align:right;"> 9352.470 </td>
   <td style="text-align:right;"> 15201.440 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 17 </td>
   <td style="text-align:right;"> 3725.878 </td>
   <td style="text-align:right;"> 6283.250 </td>
   <td style="text-align:right;"> 5736.560 </td>
   <td style="text-align:right;"> 5128.127 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 19 </td>
   <td style="text-align:right;"> 10846.250 </td>
   <td style="text-align:right;"> 13891.583 </td>
   <td style="text-align:right;"> 14803.670 </td>
   <td style="text-align:right;"> NA </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 20 </td>
   <td style="text-align:right;"> 9963.565 </td>
   <td style="text-align:right;"> 9211.125 </td>
   <td style="text-align:right;"> 12225.282 </td>
   <td style="text-align:right;"> 10081.030 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 21 </td>
   <td style="text-align:right;"> 5035.065 </td>
   <td style="text-align:right;"> 5748.627 </td>
   <td style="text-align:right;"> 6117.688 </td>
   <td style="text-align:right;"> 7204.748 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 22 </td>
   <td style="text-align:right;"> 5066.752 </td>
   <td style="text-align:right;"> 4134.533 </td>
   <td style="text-align:right;"> 5006.845 </td>
   <td style="text-align:right;"> 7975.283 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 201 </td>
   <td style="text-align:right;"> 1396.033 </td>
   <td style="text-align:right;"> 4249.562 </td>
   <td style="text-align:right;"> 2533.628 </td>
   <td style="text-align:right;"> 2206.812 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 203 </td>
   <td style="text-align:right;"> 1451.470 </td>
   <td style="text-align:right;"> 1501.438 </td>
   <td style="text-align:right;"> 1909.753 </td>
   <td style="text-align:right;"> 2472.343 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 204 </td>
   <td style="text-align:right;"> 3164.688 </td>
   <td style="text-align:right;"> 3173.847 </td>
   <td style="text-align:right;"> 2792.125 </td>
   <td style="text-align:right;"> 1676.000 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 205 </td>
   <td style="text-align:right;"> 6456.967 </td>
   <td style="text-align:right;"> 11925.468 </td>
   <td style="text-align:right;"> 7450.278 </td>
   <td style="text-align:right;"> 11345.407 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 206 </td>
   <td style="text-align:right;"> 3736.810 </td>
   <td style="text-align:right;"> 3707.875 </td>
   <td style="text-align:right;"> 3223.593 </td>
   <td style="text-align:right;"> 4985.440 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 207 </td>
   <td style="text-align:right;"> 5083.280 </td>
   <td style="text-align:right;"> 6428.315 </td>
   <td style="text-align:right;"> 6700.748 </td>
   <td style="text-align:right;"> 5199.312 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 208 </td>
   <td style="text-align:right;"> 2612.250 </td>
   <td style="text-align:right;"> 3449.810 </td>
   <td style="text-align:right;"> 2482.940 </td>
   <td style="text-align:right;"> 3263.970 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 209 </td>
   <td style="text-align:right;"> 2126.185 </td>
   <td style="text-align:right;"> 3625.500 </td>
   <td style="text-align:right;"> 2563.718 </td>
   <td style="text-align:right;"> 2967.907 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 210 </td>
   <td style="text-align:right;"> 5690.440 </td>
   <td style="text-align:right;"> 6105.592 </td>
   <td style="text-align:right;"> 6664.688 </td>
   <td style="text-align:right;"> 5098.160 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 212 </td>
   <td style="text-align:right;"> 4699.658 </td>
   <td style="text-align:right;"> 5192.250 </td>
   <td style="text-align:right;"> 4647.190 </td>
   <td style="text-align:right;"> 5065.035 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 214 </td>
   <td style="text-align:right;"> 3628.378 </td>
   <td style="text-align:right;"> 4118.707 </td>
   <td style="text-align:right;"> 5185.467 </td>
   <td style="text-align:right;"> 2026.030 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 215 </td>
   <td style="text-align:right;"> 4432.130 </td>
   <td style="text-align:right;"> 4132.312 </td>
   <td style="text-align:right;"> 5207.998 </td>
   <td style="text-align:right;"> 5075.938 </td>
  </tr>
</tbody>
</table>

\clearpage

### Interrogative processing cost is represented in IRT

Interrogatives appear to have a computational processing cost when compared to interrogatives [cf. @mehler1963some, @qp2]. The filler sentences in this study were designed so as to provide a diagnostic of the interrogative effect on IRT. 

<!--html_preserve--><table class="huxtable" style="border-collapse: collapse; margin-bottom: 2em; margin-top: 2em; width: 50%; margin-left: auto; margin-right: auto;  ">
<col><col><col><col><tr>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0pt 0pt; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">Only Interogitivity</td>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">Full</td>
<td style="vertical-align: top; text-align: center; white-space: nowrap; border-style: solid solid solid solid; border-width: 0.8pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">No interaction</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(Intercept)</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">6236.06&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">6261.55&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">6226.62&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(554.38)</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(573.11)</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(565.57)</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">Q</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">379.21&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">311.62&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">379.40&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(155.31)</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(236.77)</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(155.32)</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">+GP</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-49.00&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">18.69&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(284.55)</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">(221.71)</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">Q * +GP</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">135.53&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;"></td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">(357.36)</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.4pt 0pt; padding: 4pt 4pt 4pt 4pt;">&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">N</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">998&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">998&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">998&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">logLik</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-9278.27&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-9278.20&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; padding: 4pt 4pt 4pt 4pt;">-9278.27&nbsp;</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: left; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">AIC</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">18566.54&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">18570.39&nbsp;</td>
<td style="vertical-align: top; text-align: right; white-space: nowrap; border-style: solid solid solid solid; border-width: 0pt 0pt 0.8pt 0pt; padding: 4pt 4pt 4pt 4pt;">18568.54&nbsp;</td>
</tr>
<tr>
<td colspan="4" style="vertical-align: top; text-align: left; white-space: normal; padding: 4pt 4pt 4pt 4pt;"> *** p &lt; 0.001;  ** p &lt; 0.01;  * p &lt; 0.05.</td>
</tr>
</table>
<!--/html_preserve-->

The mean IRT for interrogative fillers was 6.2s; for declarative, 6.6s. Interrogatives elicited a mean IRT of 0.4s longer than declaratives. Half of the fillers had a string of two PPs at the end (+PP), and the other half had no trailing PPs (-PP). This did not impact IRT to the same degree (a difference of 0.02s across &plusmn;PP). When we look at -PP only, the impact of interrogativty on mean IRT is 0.3s, and for only +PP it's 0.4s.

A mixed effects regression model (no random slope structure, due to convergence errors) found a significant main effect of &plusmn;Q (estimate = 0.38s, t = 2.24, p < 0.05), but not for &plusmn;PP or the interaction of interrogativity with &plusmn;PP.

\clearpage

## Delay comparison for cold vs. previewed readings

A comparison of the delay for cold readings compared with that of previewed readings can lend insight into the extent to which subjects followed task instructions.

"Delay" here is the amount of time after the start of a recording until the beginning of phonation of the target sentence. Cold readings are also called "reading 1", while previewed readings are the same as "reading 2". Implausible delays of >15s are excluded in the data shown here.

<div class="figure">
<img src="4-results_files/figure-html/delayComparison-1.png" alt="Delay comparison across reading" width="672" />
<p class="caption">(\#fig:delayComparison)Delay comparison across reading</p>
</div>

For each reading, n = 489 (total n = 978).

# Reading 1 delay category




Reading 1 (R1) delay is the amount of time between the initial display of a sentence and the start of phonation. Participants' median R1 delay ranged from 0.60s to 1.60s with a standard deviation of 0.25s. As a way of analyzing the protocol, and the extent to which participants performed as expected, participants were categorized based on their median R1 delay. In what follows, a fast median R1 delay is shorter than or equal to 0.90s, and a slow one is longer than 1.05s, resulting in 12 participants per category. Ten other participants categorized as "normal" and ignored. The distribution of participants across categories is shown in table \ref{tab:delcat}. These calculations were done over Reading 1 of experimental items (n = 489, with 23 missing items).

<table class="table" style="width: auto !important; margin-left: auto; margin-right: auto;">
<caption>(\#tab:delcat)Participants by Reading 1 delay category</caption>
 <thead>
  <tr>
   <th style="text-align:left;"> Delay category </th>
   <th style="text-align:right;"> n </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> FAST </td>
   <td style="text-align:right;"> 12 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> SLOW </td>
   <td style="text-align:right;"> 12 </td>
  </tr>
</tbody>
<tfoot>
<tr><td style="padding: 0; border: 0;" colspan="100%"><span style="font-style: italic;">Note: </span></td></tr>
<tr><td style="padding: 0; border: 0;" colspan="100%">
<sup></sup> FAST median R1 delay $\\leq$ 0.90s. SLOW median R1 delay $&gt;$ 1.05s</td></tr>
</tfoot>
</table>

The prosodic patterns produced by participants categorized as having fast or slow R1 delays were then considered separately from each other, in order to discern whether the preferred break patterns differed across that distinction. Figure \ref{fig:facet} shows the relative distribution of break patterns by condition for participants with fast and slow R1 delays.

<div class="figure">
<img src="4-results_files/figure-html/facet-1.png" alt="Plot of pattern proportions per condition" width="672" />
<p class="caption">(\#fig:facet)Plot of pattern proportions per condition</p>
</div>

The same data are shown numerically in table \ref{tab:rsplit}.

<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:rsplit)Simple break pattern by condition and R1 delay category</caption>
 <thead>
<tr>
<th style="border-bottom:hidden" colspan="2"></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="4"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">FAST (n=12)</div></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="4"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">SLOW (n=12)</div></th>
</tr>
  <tr>
   <th style="text-align:center;">   </th>
   <th style="text-align:center;">   </th>
   <th style="text-align:center;"> D -GP </th>
   <th style="text-align:center;"> Q -GP </th>
   <th style="text-align:center;"> D +GP </th>
   <th style="text-align:center;"> Q +GP </th>
   <th style="text-align:center;"> D -GP </th>
   <th style="text-align:center;"> Q -GP </th>
   <th style="text-align:center;"> D +GP </th>
   <th style="text-align:center;"> Q +GP </th>
  </tr>
 </thead>
<tbody>
  <tr grouplength="6"><td colspan="10" style="border-bottom: 1px solid;"><strong>Reading 1</strong></td></tr>
<tr>
   <td style="text-align:center;vertical-align: middle !important; padding-left: 2em;" rowspan="2" indentlevel="1"> BOTH </td>
   <td style="text-align:center;"> % </td>
   <td style="text-align:center;"> 40.4 </td>
   <td style="text-align:center;"> 43.5 </td>
   <td style="text-align:center;"> 50.0 </td>
   <td style="text-align:center;border-right:1px solid;"> 46.5 </td>
   <td style="text-align:center;"> 52.1 </td>
   <td style="text-align:center;"> 56.2 </td>
   <td style="text-align:center;"> 63.8 </td>
   <td style="text-align:center;"> 72.9 </td>
  </tr>
  <tr>
   
   <td style="text-align:center; padding-left: 2em;" indentlevel="1"> n </td>
   <td style="text-align:center;"> 19 </td>
   <td style="text-align:center;"> 20 </td>
   <td style="text-align:center;"> 24 </td>
   <td style="text-align:center;border-right:1px solid;"> 20 </td>
   <td style="text-align:center;"> 25 </td>
   <td style="text-align:center;"> 27 </td>
   <td style="text-align:center;"> 30 </td>
   <td style="text-align:center;"> 35 </td>
  </tr>
  <tr>
   <td style="text-align:center;vertical-align: middle !important; padding-left: 2em;" rowspan="2" indentlevel="1"> OBJ </td>
   <td style="text-align:center;"> % </td>
   <td style="text-align:center;"> 36.2 </td>
   <td style="text-align:center;"> 37.0 </td>
   <td style="text-align:center;"> 0.0 </td>
   <td style="text-align:center;border-right:1px solid;"> 0.0 </td>
   <td style="text-align:center;"> 27.1 </td>
   <td style="text-align:center;"> 25.0 </td>
   <td style="text-align:center;"> 0.0 </td>
   <td style="text-align:center;"> 0.0 </td>
  </tr>
  <tr>
   
   <td style="text-align:center; padding-left: 2em;" indentlevel="1"> n </td>
   <td style="text-align:center;"> 17 </td>
   <td style="text-align:center;"> 17 </td>
   <td style="text-align:center;"> 0 </td>
   <td style="text-align:center;border-right:1px solid;"> 0 </td>
   <td style="text-align:center;"> 13 </td>
   <td style="text-align:center;"> 12 </td>
   <td style="text-align:center;"> 0 </td>
   <td style="text-align:center;"> 0 </td>
  </tr>
  <tr>
   <td style="text-align:center;vertical-align: middle !important; padding-left: 2em;" rowspan="2" indentlevel="1"> PP1 </td>
   <td style="text-align:center;"> % </td>
   <td style="text-align:center;"> 23.4 </td>
   <td style="text-align:center;"> 19.6 </td>
   <td style="text-align:center;"> 50.0 </td>
   <td style="text-align:center;border-right:1px solid;"> 53.5 </td>
   <td style="text-align:center;"> 20.8 </td>
   <td style="text-align:center;"> 18.8 </td>
   <td style="text-align:center;"> 36.2 </td>
   <td style="text-align:center;"> 27.1 </td>
  </tr>
  <tr>
   
   <td style="text-align:center; padding-left: 2em;" indentlevel="1"> n </td>
   <td style="text-align:center;"> 11 </td>
   <td style="text-align:center;"> 9 </td>
   <td style="text-align:center;"> 24 </td>
   <td style="text-align:center;border-right:1px solid;"> 23 </td>
   <td style="text-align:center;"> 10 </td>
   <td style="text-align:center;"> 9 </td>
   <td style="text-align:center;"> 17 </td>
   <td style="text-align:center;"> 13 </td>
  </tr>
  <tr grouplength="6"><td colspan="10" style="border-bottom: 1px solid;"><strong>Reading 2</strong></td></tr>
<tr>
   <td style="text-align:center;vertical-align: middle !important; padding-left: 2em;" rowspan="2" indentlevel="1"> BOTH </td>
   <td style="text-align:center;"> % </td>
   <td style="text-align:center;"> 45.7 </td>
   <td style="text-align:center;"> 56.5 </td>
   <td style="text-align:center;"> 61.7 </td>
   <td style="text-align:center;border-right:1px solid;"> 69.8 </td>
   <td style="text-align:center;"> 64.6 </td>
   <td style="text-align:center;"> 40.4 </td>
   <td style="text-align:center;"> 76.6 </td>
   <td style="text-align:center;"> 75.0 </td>
  </tr>
  <tr>
   
   <td style="text-align:center; padding-left: 2em;" indentlevel="1"> n </td>
   <td style="text-align:center;"> 21 </td>
   <td style="text-align:center;"> 26 </td>
   <td style="text-align:center;"> 29 </td>
   <td style="text-align:center;border-right:1px solid;"> 30 </td>
   <td style="text-align:center;"> 31 </td>
   <td style="text-align:center;"> 19 </td>
   <td style="text-align:center;"> 36 </td>
   <td style="text-align:center;"> 36 </td>
  </tr>
  <tr>
   <td style="text-align:center;vertical-align: middle !important; padding-left: 2em;" rowspan="2" indentlevel="1"> OBJ </td>
   <td style="text-align:center;"> % </td>
   <td style="text-align:center;"> 32.6 </td>
   <td style="text-align:center;"> 17.4 </td>
   <td style="text-align:center;"> 2.1 </td>
   <td style="text-align:center;border-right:1px solid;"> 2.3 </td>
   <td style="text-align:center;"> 22.9 </td>
   <td style="text-align:center;"> 38.3 </td>
   <td style="text-align:center;"> 0.0 </td>
   <td style="text-align:center;"> 2.1 </td>
  </tr>
  <tr>
   
   <td style="text-align:center; padding-left: 2em;" indentlevel="1"> n </td>
   <td style="text-align:center;"> 15 </td>
   <td style="text-align:center;"> 8 </td>
   <td style="text-align:center;"> 1 </td>
   <td style="text-align:center;border-right:1px solid;"> 1 </td>
   <td style="text-align:center;"> 11 </td>
   <td style="text-align:center;"> 18 </td>
   <td style="text-align:center;"> 0 </td>
   <td style="text-align:center;"> 1 </td>
  </tr>
  <tr>
   <td style="text-align:center;vertical-align: middle !important; padding-left: 2em;" rowspan="2" indentlevel="1"> PP1 </td>
   <td style="text-align:center;"> % </td>
   <td style="text-align:center;"> 21.7 </td>
   <td style="text-align:center;"> 26.1 </td>
   <td style="text-align:center;"> 36.2 </td>
   <td style="text-align:center;border-right:1px solid;"> 27.9 </td>
   <td style="text-align:center;"> 12.5 </td>
   <td style="text-align:center;"> 21.3 </td>
   <td style="text-align:center;"> 23.4 </td>
   <td style="text-align:center;"> 22.9 </td>
  </tr>
  <tr>
   
   <td style="text-align:center; padding-left: 2em;" indentlevel="1"> n </td>
   <td style="text-align:center;"> 10 </td>
   <td style="text-align:center;"> 12 </td>
   <td style="text-align:center;"> 17 </td>
   <td style="text-align:center;border-right:1px solid;"> 12 </td>
   <td style="text-align:center;"> 6 </td>
   <td style="text-align:center;"> 10 </td>
   <td style="text-align:center;"> 11 </td>
   <td style="text-align:center;"> 11 </td>
  </tr>
</tbody>
<tfoot>
<tr><td style="padding: 0; border: 0;" colspan="100%"><span style="font-style: italic;">Note: </span></td></tr>
<tr><td style="padding: 0; border: 0;" colspan="100%">
<sup></sup> FAST median R1 delay $\\leq$ 0.90s. SLOW median R1 delay $&gt;$ 1.05s</td></tr>
</tfoot>
</table>

There appears to be a clear difference between the participants categorized as having fast or slow R1 delays in the extent to which they used both breaks, with the slow cateogry of participants preferring more breaks than the fast category of participants. There also seems to be a larger increase in usage of both breaks from Reading 1 to Reading 2 for the fast category than for the slow.

<!-- todo break the above down more -->

Each participants' median R1 delay can be seen in Appendix \ref{sec:r1dbyp}.

\clearpage
<!--
      TODO examine demo data
-->
