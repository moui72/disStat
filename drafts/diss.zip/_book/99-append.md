

# (APPENDIX) Appendices {-}

# Recruitment notice {#rec}

You will be asked about your reading habits and then asked to read complex sentences out loud while being audio recorded. Recordings of your voice will be analyzed, but will be kept strictly confidential. The process will take no more than 1 hour. Note that the study takes place in Queens Hall, which is about half a mile from the main Queens campus. See directions on the QC website, URL below, for how to get here. The room is 335D, on the third floor. Entrance to the building is in the back. 

# Experimental items {#items}

The D +GP and Q -GP versions of experimental items. The remaining versions can be extrapolated by applying or reversing subject-auxiliary inversion.

<table class="table" style="margin-left: auto; margin-right: auto;">
 <thead>
  <tr>
   <th style="text-align:right;"> # </th>
   <th style="text-align:left;"> Version </th>
   <th style="text-align:left;">   </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:right;vertical-align: middle !important;" rowspan="4"> 2 </td>
   <td style="text-align:left;"> D-GP </td>
   <td style="text-align:left;"> She had decided to cram the cookies in the basket from her brother-in-law. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> D+GP </td>
   <td style="text-align:left;"> She had decided to cram the cookies in the basket into her jacket pocket. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q-GP </td>
   <td style="text-align:left;"> Had she decided to cram the cookies in the basket from her brother-in-law? </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q+GP </td>
   <td style="text-align:left;"> Had she decided to cram the cookies in the basket into her jacket pocket? </td>
  </tr>
  <tr>
   <td style="text-align:right;vertical-align: middle !important;" rowspan="4"> 6 </td>
   <td style="text-align:left;"> D-GP </td>
   <td style="text-align:left;"> She had decided to put the child on the rocking horse from his parents. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> D+GP </td>
   <td style="text-align:left;"> She had decided to put the child on the rocking horse onto the see-saw. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q-GP </td>
   <td style="text-align:left;"> Had she decided to put the child on the rocking horse from his parents? </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q+GP </td>
   <td style="text-align:left;"> Had she decided to put the child on the rocking horse onto the see-saw? </td>
  </tr>
  <tr>
   <td style="text-align:right;vertical-align: middle !important;" rowspan="4"> 10 </td>
   <td style="text-align:left;"> D-GP </td>
   <td style="text-align:left;"> He had decided to stick the large check in the envelope from her church. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> D+GP </td>
   <td style="text-align:left;"> He had decided to stick the large check in the envelope into her wallet. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q-GP </td>
   <td style="text-align:left;"> Had he decided to stick the large check in the envelope from her church? </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q+GP </td>
   <td style="text-align:left;"> Had he decided to stick the large check in the envelope into her wallet? </td>
  </tr>
  <tr>
   <td style="text-align:right;vertical-align: middle !important;" rowspan="4"> 14 </td>
   <td style="text-align:left;"> D-GP </td>
   <td style="text-align:left;"> He had decided to set the board games on the floor of the living room. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> D+GP </td>
   <td style="text-align:left;"> He had decided to set the board games on the floor onto the card table. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q-GP </td>
   <td style="text-align:left;"> Had he decided to set the board games on the floor of the living room? </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q+GP </td>
   <td style="text-align:left;"> Had he decided to set the board games on the floor onto the card table? </td>
  </tr>
  <tr>
   <td style="text-align:right;vertical-align: middle !important;" rowspan="4"> 1 </td>
   <td style="text-align:left;"> D-GP </td>
   <td style="text-align:left;"> He had intended to cram the paperwork in the drawer of his filing cabinet. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> D+GP </td>
   <td style="text-align:left;"> He had intended to cram the paperwork in the drawer into his boss's desk. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q-GP </td>
   <td style="text-align:left;"> Had he intended to cram the paperwork in the drawer of his filing cabinet? </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q+GP </td>
   <td style="text-align:left;"> Had he intended to cram the paperwork in the drawer into his boss's desk? </td>
  </tr>
  <tr>
   <td style="text-align:right;vertical-align: middle !important;" rowspan="4"> 8 </td>
   <td style="text-align:left;"> D-GP </td>
   <td style="text-align:left;"> He had intended to put the bicycle on the roof rack of the minivan. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> D+GP </td>
   <td style="text-align:left;"> He had intended to put the bicycle on the roof rack into the garage. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q-GP </td>
   <td style="text-align:left;"> Had he intended to put the bicycle on the roof rack of the minivan? </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q+GP </td>
   <td style="text-align:left;"> Had he intended to put the bicycle on the roof rack into the garage? </td>
  </tr>
  <tr>
   <td style="text-align:right;vertical-align: middle !important;" rowspan="4"> 12 </td>
   <td style="text-align:left;"> D-GP </td>
   <td style="text-align:left;"> She had intended to stick the letter in the mailbox of the vice president. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> D+GP </td>
   <td style="text-align:left;"> She had intended to stick the letter in the mailbox onto the proper stack. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q-GP </td>
   <td style="text-align:left;"> Had she intended to stick the letter in the mailbox of the vice president? </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q+GP </td>
   <td style="text-align:left;"> Had she intended to stick the letter in the mailbox onto the proper stack? </td>
  </tr>
  <tr>
   <td style="text-align:right;vertical-align: middle !important;" rowspan="4"> 16 </td>
   <td style="text-align:left;"> D-GP </td>
   <td style="text-align:left;"> She had intended to set the clothes in the hamper from his sister. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> D+GP </td>
   <td style="text-align:left;"> She had intended to set the clothes in the hamper onto the dresser. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q-GP </td>
   <td style="text-align:left;"> Had she intended to set the clothes in the hamper from his sister? </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q+GP </td>
   <td style="text-align:left;"> Had she intended to set the clothes in the hamper onto the dresser? </td>
  </tr>
  <tr>
   <td style="text-align:right;vertical-align: middle !important;" rowspan="4"> 4 </td>
   <td style="text-align:left;"> D-GP </td>
   <td style="text-align:left;"> She had planned to cram the stolen files in the wall-safe of their hideout. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> D+GP </td>
   <td style="text-align:left;"> She had planned to cram the stolen files in the wall-safe into a suitcase. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q-GP </td>
   <td style="text-align:left;"> Had she planned to cram the stolen files in the wall-safe of their hideout? </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q+GP </td>
   <td style="text-align:left;"> Had she planned to cram the stolen files in the wall-safe into a suitcase? </td>
  </tr>
  <tr>
   <td style="text-align:right;vertical-align: middle !important;" rowspan="4"> 5 </td>
   <td style="text-align:left;"> D-GP </td>
   <td style="text-align:left;"> She had planned to put the jelly beans in the window of his candy store. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> D+GP </td>
   <td style="text-align:left;"> She had planned to put the jelly beans in the window onto a fancy dish. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q-GP </td>
   <td style="text-align:left;"> Had she planned to put the jelly beans in the window of his candy store? </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q+GP </td>
   <td style="text-align:left;"> Had she planned to put the jelly beans in the window onto a fancy dish? </td>
  </tr>
  <tr>
   <td style="text-align:right;vertical-align: middle !important;" rowspan="4"> 9 </td>
   <td style="text-align:left;"> D-GP </td>
   <td style="text-align:left;"> He had planned to stick the post-it note on the handout from the lecture. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> D+GP </td>
   <td style="text-align:left;"> He had planned to stick the post-it note on the handout onto his notebook. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q-GP </td>
   <td style="text-align:left;"> Had he planned to stick the post-it note on the handout from the lecture? </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q+GP </td>
   <td style="text-align:left;"> Had he planned to stick the post-it note on the handout onto his notebook? </td>
  </tr>
  <tr>
   <td style="text-align:right;vertical-align: middle !important;" rowspan="4"> 13 </td>
   <td style="text-align:left;"> D-GP </td>
   <td style="text-align:left;"> He had planned to set the appetizers on the platter from his cousin. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> D+GP </td>
   <td style="text-align:left;"> He had planned to set the appetizers on the platter onto the buffet. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q-GP </td>
   <td style="text-align:left;"> Had he planned to set the appetizers on the platter from his cousin? </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q+GP </td>
   <td style="text-align:left;"> Had he planned to set the appetizers on the platter onto the buffet? </td>
  </tr>
  <tr>
   <td style="text-align:right;vertical-align: middle !important;" rowspan="4"> 3 </td>
   <td style="text-align:left;"> D-GP </td>
   <td style="text-align:left;"> He had wanted to cram the newspapers under the sofa from the thrift store. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> D+GP </td>
   <td style="text-align:left;"> He had wanted to cram the newspapers under the sofa into the wastebasket. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q-GP </td>
   <td style="text-align:left;"> Had he wanted to cram the newspapers under the sofa from the thrift store? </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q+GP </td>
   <td style="text-align:left;"> Had he wanted to cram the newspapers under the sofa into the wastebasket? </td>
  </tr>
  <tr>
   <td style="text-align:right;vertical-align: middle !important;" rowspan="4"> 7 </td>
   <td style="text-align:left;"> D-GP </td>
   <td style="text-align:left;"> He had wanted to put the photo on the coffee table from his grandfather. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> D+GP </td>
   <td style="text-align:left;"> He had wanted to put the photo on the coffee table onto the mantelpiece. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q-GP </td>
   <td style="text-align:left;"> Had he wanted to put the photo on the coffee table from his grandfather? </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q+GP </td>
   <td style="text-align:left;"> Had he wanted to put the photo on the coffee table onto the mantelpiece? </td>
  </tr>
  <tr>
   <td style="text-align:right;vertical-align: middle !important;" rowspan="4"> 11 </td>
   <td style="text-align:left;"> D-GP </td>
   <td style="text-align:left;"> She had wanted to stick the golf clubs in the back room of their condo. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> D+GP </td>
   <td style="text-align:left;"> She had wanted to stick the golf clubs in the back room into the closet. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q-GP </td>
   <td style="text-align:left;"> Had she wanted to stick the golf clubs in the back room of their condo? </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q+GP </td>
   <td style="text-align:left;"> Had she wanted to stick the golf clubs in the back room into the closet? </td>
  </tr>
  <tr>
   <td style="text-align:right;vertical-align: middle !important;" rowspan="4"> 15 </td>
   <td style="text-align:left;"> D-GP </td>
   <td style="text-align:left;"> She had wanted to set the textbooks on the top shelf of the book shelf. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> D+GP </td>
   <td style="text-align:left;"> She had wanted to set the textbooks on the top shelf into the file box. </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q-GP </td>
   <td style="text-align:left;"> Had she wanted to set the textbooks on the top shelf of the book shelf? </td>
  </tr>
  <tr>
   
   <td style="text-align:left;"> Q+GP </td>
   <td style="text-align:left;"> Had she wanted to set the textbooks on the top shelf into the file box? </td>
  </tr>
</tbody>
</table>

# Filler items {#fillers}

The D +PP and Q -PP versions of filler items. The remaining versions can be extrapolated by applying or reversing subject-auxiliary inversion.

<table class="table" style="margin-left: auto; margin-right: auto;">
 <thead>
  <tr>
   <th style="text-align:right;"> # </th>
   <th style="text-align:left;"> Declarative garden paths without trailing PPs (D -PP) </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:right;"> 17 </td>
   <td style="text-align:left;"> She had decided to break the class into teams of six students each. </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 18 </td>
   <td style="text-align:left;"> He had forgotten to try the famous pastry in the restaurant of the fancy hotel. </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 19 </td>
   <td style="text-align:left;"> She had wanted to complete the race for charity in record time. </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 20 </td>
   <td style="text-align:left;"> He had intended to enter the expenses from the trip into a spreadsheet. </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 21 </td>
   <td style="text-align:left;"> She had meant to arrange the files in alphabetical order for her boss. </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 22 </td>
   <td style="text-align:left;"> He had needed to request some money from his father-in-law for the remodel. </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 23 </td>
   <td style="text-align:left;"> She had planned to tell the student in private about his failing grade. </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 24 </td>
   <td style="text-align:left;"> He had remembered to add the section into the handboook for the meeting. </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 25 </td>
   <td style="text-align:left;"> She had decided to instruct the staff on proper etiquette for formal dining. </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 26 </td>
   <td style="text-align:left;"> He had forgotten to tack the pamphlet on hygiene onto the notice board. </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 27 </td>
   <td style="text-align:left;"> She had wanted to find a rare butterfly on their hike in the rainforest. </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 28 </td>
   <td style="text-align:left;"> He had intended to sell his collection of baseball cards from his childhood. </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 29 </td>
   <td style="text-align:left;"> She had meant to place a suggestion box onto the front desk of the clinic. </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 30 </td>
   <td style="text-align:left;"> He had needed to set the vegan cookies onto serving trays for the party. </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 31 </td>
   <td style="text-align:left;"> She had planned to pack a ham sandwich on rye bread into her lunchbox. </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 32 </td>
   <td style="text-align:left;"> He had remembered to move the gifts from the baby shower onto the bed. </td>
  </tr>
</tbody>
</table>

<table class="table" style="margin-left: auto; margin-right: auto;">
 <thead>
  <tr>
   <th style="text-align:right;"> # </th>
   <th style="text-align:left;"> Interrogative fillers with trailing PPs (Q +PP) </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:right;"> 33 </td>
   <td style="text-align:left;"> Had she wanted to bring her son when she attended the next conference? </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 34 </td>
   <td style="text-align:left;"> Had he remembered to tell the office manager to order more coffee filters? </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 35 </td>
   <td style="text-align:left;"> Had she planned to finish preparing dinner while the guests were chatting? </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 36 </td>
   <td style="text-align:left;"> Had he needed to upgrade his ticket when he changed his travel plan? </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 37 </td>
   <td style="text-align:left;"> Had she meant to write up the performance reviews to give her employees? </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 38 </td>
   <td style="text-align:left;"> Had he intended to do the work that the boss asked a coworker to do? </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 39 </td>
   <td style="text-align:left;"> Had she forgotten to report that the clerk was ignoring her request? </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 40 </td>
   <td style="text-align:left;"> Had he decided to do the needed repairs on the broken-down van himself? </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 41 </td>
   <td style="text-align:left;"> Had she wanted to tell her friends that she was selling her vacation home? </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 42 </td>
   <td style="text-align:left;"> Had he decided to advise that his newest patient seek a second opinion? </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 43 </td>
   <td style="text-align:left;"> Had she forgotten to lock the gate that was supposed to be kept closed? </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 44 </td>
   <td style="text-align:left;"> Had he intended to replace the crackers he ate while he was house sitting? </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 45 </td>
   <td style="text-align:left;"> Had she meant to try to get the program to run on the new operating system? </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 46 </td>
   <td style="text-align:left;"> Had he needed to beg to get his old job back when his investment failed? </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 47 </td>
   <td style="text-align:left;"> Had she planned to build herself a new computer when she got her paycheck? </td>
  </tr>
  <tr>
   <td style="text-align:right;"> 48 </td>
   <td style="text-align:left;"> Had he remembered to circulate the latest job posting his company had sent? </td>
  </tr>
</tbody>
</table>

# Instructions to participants {#instr}

Thank you kindly for your participation. In this study, you are being asked to read complex sentences out loud, twice each. It is very important that you follow these guidelines for each of your readings.

First reading: Begin reading immediately, without giving yourself a chance to look ahead. Imagine you are a television reporter reading an urgent update from a teleprompter. You must be as quick as possible, without taking any time to read ahead.  You want to sound natural if you can, but it is more important to not delay. These sentences are complicated and potentially confusing. It’s very important that you read the sentence out loud as soon as it appears. It’s OK if you make mistakes or don’t understand, that is an important part of what I want to know. Do the best you can, and remember you have another chance to read it. 

Second reading: This time you have the luxury of pacing yourself as you please. Imagine you are providing a voice-over for a documentary. You want to sound conversational and clear, without being overly dramatic or formal. Study the sentence as long as you like, and be sure that you understand it before you begin reading. It is most important to sound natural, without worrying about how long it takes to prepare.

The experiment will begin with brief instructions, recapping what you are reading now. There will then be a practice session to get you comfortable with the task and a chance for you to ask any questions you have. Finally, after your questions are answered, the study will begin in earnest.

Each sentence will follow the same pattern. You will be presented with a screen which displays a series of plus signs. This indicates that the system is ready and that you should press the button labeled “START” when you are ready to read a sentence. As soon as you press the button, the sentence will appear and you should begin your first reading. After you have completed the reading, press the button labeled “NEXT.” You should allow a small amount of time after you finish and before you hit “NEXT,” to ensure that the recording is not cut off too early. 

Once you have pressed “NEXT,” you will see a brief instructions slide to help you keep track of where you are. You should then press “START” and begin preparing to read the second time. The background color will change to confirm that the computer has registered your key press. Once you’re ready, read the sentence aloud for the second time and then press “DONE.” Once again, be sure not to cut yourself off. Wait a moment after you finish reading before pressing “DONE.”

You are not being judged or measured in any way. Rather, we are interested in how these sentences are pronounced by native speakers of English. Any confusion you have or mistakes you make are interesting properties of the sentences, not failings of you, the speaker.

The keys used during the experiment are clearly labeled, but the function of each key is listed below for your reference. There is no hurry for pressing the keys. The only timing of importance is that you begin reading as quickly as possible after pressing “START.” The task should take no longer than one hour

The instruction also contained a table (table \@ref(tab:keytab)) which described the purpose and position of the relevant buttons on the keyboard. A separate page with just this table was also provided, and participants were allowed to keep the instructions with them during the entire procedure.

<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:keytab)Table of keyboard mappings</caption>
 <thead>
  <tr>
   <th style="text-align:left;"> Label </th>
   <th style="text-align:left;"> Position </th>
   <th style="text-align:left;"> Description </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> Start </td>
   <td style="text-align:left;"> Left shift </td>
   <td style="text-align:left;"> Revewal a sentence and begin your reading. </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Next </td>
   <td style="text-align:left;"> Right shift </td>
   <td style="text-align:left;"> End your first reading. </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Done </td>
   <td style="text-align:left;"> Thumb pad </td>
   <td style="text-align:left;"> End your second reading and prepare for the next sentence. </td>
  </tr>
</tbody>
</table>


# Instructions to RA {#RA}

Before you begin describing the recordings for a given speaker, please familiarize yourself with that speaker. To do so, please listen to recordings numbered 46-48 and 24-27.

Next, move on to describings the recordings numbered 1-16. Please listen to them in the following pattern: begin with either 1Y or 1X, and listen to the recordings sequentially (or reverse sequentially), and alternate between X and Y versions. Then, repeat the process for the inverse versions (X vs. Y). Please then listen to the next speaker, beginning with 16X or Y, and then listen in reverse sequence, alternating X vs. Y, and then again repeat for the other half. In this way, please alternate across speakers between listening to X or Y first as well as 1 or 16 first.

For each recording, please respond in the spreadsheet using the following guidelines for the columns. Each recording should get its own row.

* Speaker ID: This should be the name of the directory in which the recording exists.
* Recording ID: This should be the filename of the recording being described
* X or Y: This should be the last character of the filename, either X or Y.
* First recording for speaker: This should indicate which recording you started with first, which will allow me to deduce the pattern you used to listened to the recordings, per above, e.g. 1X, 1Y, 16X or 16Y.

For columns E-K, Consider a given sentence to be divided into regions, as in the following example:

<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:reg)Sentence region labels</caption>
 <thead>
  <tr>
   <th style="text-align:left;"> SUBJ </th>
   <th style="text-align:left;">   </th>
   <th style="text-align:left;"> V </th>
   <th style="text-align:left;">   </th>
   <th style="text-align:left;"> OBJ </th>
   <th style="text-align:left;"> PP1 </th>
   <th style="text-align:left;"> PP2 </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> He </td>
   <td style="text-align:left;"> had </td>
   <td style="text-align:left;"> meant </td>
   <td style="text-align:left;"> to stick ||$_V$ </td>
   <td style="text-align:left;"> the pencil case ||$_{OBJ}$ </td>
   <td style="text-align:left;"> in the cabinet ||$_{PP1}$ </td>
   <td style="text-align:left;"> into his book bag. </td>
  </tr>
  <tr>
   <td style="text-align:left;"> NP$_{SUBJ}$ </td>
   <td style="text-align:left;"> AUX </td>
   <td style="text-align:left;"> V$_1$ </td>
   <td style="text-align:left;"> V$_2$ </td>
   <td style="text-align:left;"> NP$_{OBJ}$ </td>
   <td style="text-align:left;"> PP$_1$ </td>
   <td style="text-align:left;"> PP$_2$ </td>
  </tr>
</tbody>
</table>

Please work with the assumption that “prosodic boundary” in what follows is any subset of the following features, clustered in such a way as to trigger your intuition that a new prosodic element (of any size) is beginning: pitch change, volume change, segmental lengthening, or pause.

* Break after V?: Please indicate whether or not you think there is a prosodic boundary after the verb cluster(at the right edge of the last/main verb).
* Break after OBJ?: Please indicate whether or not you think there is a prosodic boundary after the first NP in the object region (at the right edge of the first NP in the object region).
* Break after PP1?: Please indicate whether or not you think there is a prosodic boundary after the first NP in the PP1 region (at the right edge of the first NP in the PP region).
* Strongest break? Please indicate which of the breaks (columns E-G where you indicated YES) you think is strongest. If two breaks are of equal strength and are stronger than a third, indicate NONE as strongest. If two breaks are of equal strength and are weaker than a third, indicate that third break as strongest. If all breaks are the same strength, indicate NONE as strongest.
* Weakest break? Please indicate which of the breaks (columns E-G where you indicated YES) you think is weakest. If two breaks are of equal strength and are weaker than a third, indicate NONE as weakest. If two breaks are of equal strength and are stronger than a third, indicate that third break as weakest. If all breaks are the same strength, indicate NONE as weakest
* Struggle?: Indicate whether or not the speaker appears to have had difficulty reading the sentence. This should be relative to their baseline reading fluency, so if a person is hesitant every time, hesitance should not be enough to indicate a struggle.
* Start of struggle: indicate the region in which you first notice the speaker struggling.
*Question?: indicate simply whether or not the recording sounds like a question, prosodically (e.g. final rise is present).

# Median R1 delay by participant {#r1dbyp}



Table \ref{tab:pmedians} shows each participants' median R1 delay.

<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:pmedians)Median R1 delay by participant</caption>
 <thead>
  <tr>
   <th style="text-align:center;"> # </th>
   <th style="text-align:center;"> Median R1 delay </th>
   <th style="text-align:center;"> R1 delay category </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:center;"> 1 </td>
   <td style="text-align:center;"> 600 </td>
   <td style="text-align:center;"> FAST </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 2 </td>
   <td style="text-align:center;"> 615 </td>
   <td style="text-align:center;"> FAST </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 3 </td>
   <td style="text-align:center;"> 675 </td>
   <td style="text-align:center;"> FAST </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 4 </td>
   <td style="text-align:center;"> 690 </td>
   <td style="text-align:center;"> FAST </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 5 </td>
   <td style="text-align:center;"> 750 </td>
   <td style="text-align:center;"> FAST </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 6 </td>
   <td style="text-align:center;"> 765 </td>
   <td style="text-align:center;"> FAST </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 7 </td>
   <td style="text-align:center;"> 765 </td>
   <td style="text-align:center;"> FAST </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 8 </td>
   <td style="text-align:center;"> 780 </td>
   <td style="text-align:center;"> FAST </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 9 </td>
   <td style="text-align:center;"> 825 </td>
   <td style="text-align:center;"> FAST </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 10 </td>
   <td style="text-align:center;"> 855 </td>
   <td style="text-align:center;"> FAST </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 11 </td>
   <td style="text-align:center;"> 900 </td>
   <td style="text-align:center;"> FAST </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 12 </td>
   <td style="text-align:center;"> 900 </td>
   <td style="text-align:center;"> FAST </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 13 </td>
   <td style="text-align:center;"> 915 </td>
   <td style="text-align:center;"> NORMAL </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 14 </td>
   <td style="text-align:center;"> 930 </td>
   <td style="text-align:center;"> NORMAL </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 15 </td>
   <td style="text-align:center;"> 960 </td>
   <td style="text-align:center;"> NORMAL </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 16 </td>
   <td style="text-align:center;"> 960 </td>
   <td style="text-align:center;"> NORMAL </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 17 </td>
   <td style="text-align:center;"> 990 </td>
   <td style="text-align:center;"> NORMAL </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 18 </td>
   <td style="text-align:center;"> 1005 </td>
   <td style="text-align:center;"> NORMAL </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 19 </td>
   <td style="text-align:center;"> 1020 </td>
   <td style="text-align:center;"> NORMAL </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 20 </td>
   <td style="text-align:center;"> 1050 </td>
   <td style="text-align:center;"> NORMAL </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 21 </td>
   <td style="text-align:center;"> 1065 </td>
   <td style="text-align:center;"> SLOW </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 22 </td>
   <td style="text-align:center;"> 1080 </td>
   <td style="text-align:center;"> SLOW </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 23 </td>
   <td style="text-align:center;"> 1095 </td>
   <td style="text-align:center;"> SLOW </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 24 </td>
   <td style="text-align:center;"> 1110 </td>
   <td style="text-align:center;"> SLOW </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 25 </td>
   <td style="text-align:center;"> 1140 </td>
   <td style="text-align:center;"> SLOW </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 26 </td>
   <td style="text-align:center;"> 1200 </td>
   <td style="text-align:center;"> SLOW </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 27 </td>
   <td style="text-align:center;"> 1290 </td>
   <td style="text-align:center;"> SLOW </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 28 </td>
   <td style="text-align:center;"> 1320 </td>
   <td style="text-align:center;"> SLOW </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 29 </td>
   <td style="text-align:center;"> 1335 </td>
   <td style="text-align:center;"> SLOW </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 30 </td>
   <td style="text-align:center;"> 1365 </td>
   <td style="text-align:center;"> SLOW </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 31 </td>
   <td style="text-align:center;"> 1410 </td>
   <td style="text-align:center;"> SLOW </td>
  </tr>
  <tr>
   <td style="text-align:center;"> 32 </td>
   <td style="text-align:center;"> 1605 </td>
   <td style="text-align:center;"> SLOW </td>
  </tr>
</tbody>
</table>
