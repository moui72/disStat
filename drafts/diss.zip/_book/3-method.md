
# Methodology 
This section outlines the methodology employed for the reported study. The methodology outlined is referred to as the *Double Reading Procedure* and was first implemented by @fodor2019center. Participants are asked to read sentences twice, once without any previewed (Reading 1), and then again after unlimited preview (Reading 2).

## A note on the *Double Reading Procedure*

An advantage that the *Double Reading Procedure* has is that it allows for certain assumptions to be made about Reading 2 that otherwise would be unclear: Reading 2 represents a considered reading of the sentence. Not only has the reader had ample time to examine the sentence, they have necessarily read it, and they have heard themselves read it. We can say this with certainly, because they have necessarily already produce a recording of Reading 1. This means Reading 2 represents a considered prosodic structure, and it should not represent any processing issues, because a parse should have already been obtained during Reading 1.

The nature of Reading 1 is less clear. Because there is variability in the delay between the display of the sentence and the onset of phonation, it's possible that Reading 1 is not entirely non-previewed. The properties of these Reading 1 delays are discussed at length in \ref{sec:r1del}, but for now it suffices to say that the amount of preview that is possible during a delay that typically falls in the 0.6s to 1.6s range is very limited. As an example of common reading rates, @ashby2012eye reported faster readers as averaging 328 words per minute (wpm), and slower readers 228wpm in silent reading with 3 word windows allowing for parafoveal processing. That study found that reading time is slower for reading aloud, and that the availability of parafoveal information (i.e. the difference between 1 word and 3 word windows) is less impactful for that reading mode. For reading aloud, faster readers were slowed to an average of 213wpm, and slower readers to an average of 183wpm with 3 word windows.

We can say about Reading 1, at the very least, that a full parse of the sentence is not possible during the time before phonation begins, even delays in the 1.6s range. The utterance of Reading 1 should contain within it any behavioral reflex of whatever parsing difficult the reader has.

## Participants recruitment

The participants in this study were all undergraduate students at Queens College, CUNY, enrolled in Psychology 101. These students were required by the university to participant in studies for course credit. Self reported age ranged from 18 to 25 years. Participants were recruited using the Queens College Sona system, which is software designed for university participant pools. Students saw a notice on the Sona website (see Appendix \ref{sec:rec}) and were able to schedule their own appointment time within the hours offered (Monday - Thursday, 10am to 4pm).

All participants were self identified native and primary speakers of American English. One participant was disqualified post-hoc after producing a Caribbean English pronunciation pattern; one other participant was excluded post-hoc due to an extremely disfluent reading cadence. Both excluded participants were still awarded class credit for participating

## Location

All data were collected in a private room with only the experimenter and participant present. While every effort was undertaken to ensure a quiet environment, intrusive noise from passersby or neighboring rooms were sometimes unavoidable. This resulted in some unusable or partially unusable recordings (discussed in section \@ref(results-irt) of the results chapter).

## Equipment and software

The experiment was presented on a laptop running Windows 10 with stickers on the keyboard labeling relevant keys. The left shift key was labeled *START*, right shift was labeled *NEXT*, and the touch-pad was labeled *DONE*.

The presentation of items and instruction[^instr] was done using the Open Sesame software [@os2012] which provides a graphical user interface, scripting language, and interpretation of Python code, for precise control of experimental presentation.

Recording was done using a Blue Yeti USB microphone position near the participant's left hand and angled to point at the space in front of the participant's mouth. The angle was adjusted for each participant's height. It recording 44.1kHz single-channel audio.

[^instr]: Instructions were also provided verbally and via printout. Details on the instructions are available in the appendices \@ref(sec:instr).

## Procedure
Participants were given a verbal overview of the experimental procedure and then asked to read a one page printout of the procedure before signing a consent form. After signing a consent form, participants sat at the computer and were once again walked through instructions before the first practice item was presented.

Participants sat at a computer and used keyboard button presses to navigate the experimental presentation. They received thorough instructions and completed three practice items, the consulted with the experimenter, before beginning the main portion of the study. The study also contained 4 pseudo-practice items that were not included in any analyses, in order to allow some time for the participant to settle into the procedure before any results were recorded.

Each experimental item was preceded by a screen showing a line of ten Xes with its left edge aligned with the left edge of the to-be-revealed sentence. This was intended to fix the participant's attention on the start of the sentence, and hopefully avoid unintended look-ahead. The issue of potential look-ahead is discussed at greater length in section \ref{sec:look-ahead}

This screen remained visible indefinitely, until the participant pressed *START*.

Immediately after *START* was pressed, recording of the first reading began and the sentence appeared on the screen on a blue background. The recording continued and the screened remained visible until the participant pressed *NEXT*. After pressing *NEXT*, a screen appeared with instructions telling the participant that they were between readings, and needed to press *START* to reveal the sentence again and prepare for their second reading. Immediately after *START* was pressed, the first recording ended and the second recording began, and the sentence reappeared, this time on a green background.

![Procedure diagram](dissertation-procedure.png)

The shifting of required key presses and the changing background color were intended to aid the participant in remember where they were in the process, and to prevent accidental double-presses of any given button from having unintended side effects. It took some time for the participants to adapt to the somewhat complicated procedure, but generally were well adjusted by the time the first item was presented.

### On look-ahead {#look-ahead}

As reported by @rayner2012psychology, the perceptual span during reading is about 31 characters, or about 15 characters to either side, with an asymmetry favoring the direction in which reading occurs (i.e. wider to the right for English readers, wider to the left for Arabic readers) and a lack of importance of parafoveal information beyond the start of the fixated word in the direction of what has already been read (i.e. to the left in English). Rayner et al. show that at the extreme edges of this perceptual span, it appears to be only the presence and absence spaces that is shown to be available. Character shape (but not identity; e.g. whether a letter has ascenders or descenders) is available 10 characters to either side,

With a fixation aligned with the left edge of a stimuli, focal attention is likely centered on the third or fourth character. The resulting potential for look ahead can be diagrammed as follows, assuming initial fixation on *had*,  using a notation where a character whose identity can likely be extracted is reproduced, a character whose shape but not identity can be extracted is represented by an x, b, or j (depending on the shape of the original character, i.e. if the original character has an ascender, I've represented it with a b, if it has a descender I have represented it with a j, and if it has neither I've represented it with an x). Characters entirely outside of the perceptual span are represented with an x. Spaces are inserted only as far out as they could be identified, and otherwise filled with an x.

  (@la1) XXXXXXXXXX *(fixation slide)* <br/>
         He had intendxb bx nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn <br/>
         He had intended to cram the paperwork in the drawer of his filing cabinet.
         
Critically, the disambiguation PP2 region (in @la1, *of his filing cabinet*) is not within the perceptual span until, at the earliest, one is in the object region (*the paperwork*). It is important to note as well, though, that when PP1, the phrase with ambiguous attachment site, is the fixation point, the existence of PP2 at least, is within the perceptual span. If we assume fixation on *the*, the available information should be something something like (@la2).

  (@la2) nnnnnnnnnnnnnnnnnnnnnnn nnn nnjxxxxxb in the drawer xb bxnnnnnnnnnnnnnnnnn <br/>
         He had intended to cram the paperwork in the drawer of his filing cabinet.

There is, therefore, the potential that look-ahead while reading PP1 could trigger the garden path effect of PP2 early, because it can be deduced that a short and then longer word are coming up on the periphery. The reader is likely to be aware as early as this point that something may be wrong with the parse that attaches PP1 as an argument of the verb, as that parse has limited available real-estate for further phrases. 

Another wrinkly involves the so-called eye-voice span (EVS). According to @evs, when reading aloud, the voice is typically behind the eyes by 10-20 characters, varying with various properties of the text and different parts of the reading cycle. Thus, it's difficult to know exactly where in the recording a reflex of the garden path would occur, but it is likely to be before the actually phonation of the disambiguating region. Most likely seems to be a hesitation in or around the previous phrase, i.e. PP1. This to some degree confounds the analysis of a pause after that phrase: it could be an intentional prosodic break, or it could be added processing time as a result of the reader discovering the garden path. This issue is revisited during discussion of the results.

## Materials

A number of considerations went into creating the materials for this study. The experimental stimuli are based on earlier pilot study exploring this same phenomenon [@qp2], but with several issues with that study's experimental items corrected.

One of these issues was that the verbs did not all strongly sub-categorize for a PP-argument. This could affect the strength of the garden path effect, since the strength of that sub-categorization might impact the amount of influence that the parsing strategy of *Minimal Attachment* or *Argument Preference* has on the parse. Theoretically, verbs with stronger sub-categorization for a PP-argument would result in a stronger garden path effect, or more difficulty in understanding the sentence. 

Another issue had to do with the level of detail present in the sentences, especially when they were presented as yes/no-questions. When it’s clear that the speaker already knows so much about the situation, it becomes difficult to imagine a pragmatically plausible context where the question would be asked. Such sentences might be described as “prosecutorial[^dcbp].” 

There was also an issue of whether the temporary ambiguity in some of the non-garden path items was ever fully disambiguated. This section will go over considerations taken in order to adjust the stimuli from the earlier study into more systematic and consistent format. The construction of these items is discussed in detail in the rest of this section.

[^dcbp]: Thank you to Dianne Bradley for making this observation, and for the very clever “prosecutorial” descriptor.

### Four versions of the experimental items

The experimental items for this study consisted of 16 sentences in 4 versions: declarative and yes/no interrogative versions of both a PP-attachment garden path of the type discussion earlier, and a non-garden path control which is identical to the garden path up until the final PP, when that PP disambiguates the sentence such that the parse is plausible with a PP2 that modifies the head noun of PP1. The interrogative is always identical to the declarative in every way except for inversion of the order of the subject and auxiliary verb, and the replacement of a final period with a final question mark. An example item in all four versions is shown in \@ref(tab:sentences).

<table>
<caption>(\#tab:sentences)Experimental item in four versions</caption>
 <thead>
  <tr>
   <th style="text-align:left;"> Version </th>
   <th style="text-align:left;"> Sentence </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> Declarative non-garden path </td>
   <td style="text-align:left;"> He had intended to cram the paperwork in the drawer of his filing cabinet. </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Interrogative non-garden path </td>
   <td style="text-align:left;"> Had he intended to cram the paperwork in the drawer of his filing cabinet? </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Declarative garden path </td>
   <td style="text-align:left;"> He had intended to cram the paperwork in the drawer into his boss's desk. </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Interrogative garden path </td>
   <td style="text-align:left;"> Had he intended to cram the paperwork in the drawer into his boss's desk? </td>
  </tr>
</tbody>
</table>

### Main verbs in experimental items

An earlier pilot study exploring this same phenomenon (Peckenpaugh, 2016) had several issues with its materials. One of these issues was that the verbs did not all strongly sub-categorize for a PP-argument. This could affect the strength of the garden path effect, since the strength of that sub-categorization might impact the amount of sway that the parsing strategy of Minimal Attachment or Argument Preference has on the parse. Theoretically, verbs with stronger sub-categorization for a PP-argument would result in a strong garden path effect.


  (@weak) Weak PP-argument sub-categorization (*hide*) 
  
  a. The gangsters had hidden the shotguns in a U-Haul truck in an old outhouse. 
  b. \checkmark The gangsters had hidden the shotguns.
            
  (@strong) Strong PP-argument sub-categorization (*cram*) 
  
  a. Justin had crammed the old newspapers under the couch in a small wastebasket.
  b. \* Justin had crammed the old newspapers.


The examples in (@weak) and (@strong) point out that while you really must cram something somewhere, you don’t necessarily need to say where you hide something. That is, the verb *hide* seen in (@weak) does not strongly sub-categorize for a locative argument (hence the acceptability of (@weak~\tiny ~b)), while cram (@strong) does, rendering (@strong~\tiny ~b) unacceptable. Because of the asymmetry in sub-categorization strength, sentences like (@weak) might not trigger as strong a garden-path effect, because the parser might assume that no PP-argument is forthcoming, while for (@strong) the parser will jump at the opportunity to parse a PP as an argument.  In designing the items for this study, only verbs with strong PP-argument sub-categorization were used. The four verbs selected were: *cram*, *put*, *stick* and *set*.

### Complex tense

To minimize the morphology present on the PP-argument-selecting main verb (e.g. *cram*), each sentence contained a past-tense auxiliary verb and past participle verb before the infinitive version of the main verb. The use of an auxiliary makes the words present in the declarative exactly the same as in the interrogative by eliminating the need for "do-support" and adjusted morphology on the main verb (i.e. rather than "He crammed ..." vs. "Did he cram ...?" we have "He had crammed ..." vs. "Had he crammed ...?"). The auxiliary is always *had* and the past participle is always one of the following four: *decided*, *intended*, *wanted*, and *planned*. The presence of these preface verbs also help to alleviate the oddity of the yes/no questions, because it is understandable to question someone's intentions, even when a large amount of detail is already known; whereas, questioning the details themselves when they are already known leads to the "prosecutorial" issue mentioned earlier.

  (@lessPros) Had he intended to put the bicycle on the roof rack of the minivan?
  (@pros) Had he put the bicycle on the roof rack of the minivan?
  
It seems less odd to wonder whether *he had intended* to do something, as in (@lessPros) when we know so many details, rather than to wonder if he did as in (@pros); that is, it is presupposed that he did the thing, but we are left to wonder about his intention. The preface verb also seems to attract the focus of the yes/no question, providing a somewhat controlled environment for what can be difficult to ascertain: in (@pros) the focus could be on any number of elements, with no easily assumed default. The default focus in (@lessPros) seems most likely to be on *planned*.


### Prepositions and disambiguation

Every version of each experimental item should be fully disambiguated by the preposition heading the final PP. When PP2 attaches low, a preposition that is not compatible with being the resultative/locative argument of the verb but can be a modifier of the noun of the preceding PP is used: *from* or *of*. When the final PP attaches high, a preposition that is not compatible with being a modifier of the noun in the preceding PP but can be the resultative/locative argument of the verb is used: *into* or *onto*.

  (@low)  Had he planned to set the appetizers on [~NP~ the platter [~PP2~ *from* his cousin]]?
  (@high) Had he planned to set the appetizers on [~NP~ the platter] [~PP2~ *onto* the buffet]?
  
This clear disambiguation should prevent any lingering processing issues due to ambiguity in the non-garden path versions of the sentences.

### Fillers

There were 32 filler items that ranged in complexity. Of these 32, 16 were designed to end in a sequence of two PPs, to mirror the experimental items (+PP). The other half contained no final PPs (-PP). All fillers were designed in two versions: declarative (D) and interrogative (Q). The +PP fillers were not related to the -PP fillers.

  (@fillerdpp) He had forgotten to try the famous pastry in the restaurant of the fancy hotel.
  (@fillerqpp) Had he forgotten to try the famous pastry in the restaurant of the fancy hotel?
  
  (@fillerd) She had forgotten to report that the clerk was ignoring her request.
  (@fillerq) Had she forgotten to report that the clerk was ignoring her request?

A full list of fillers is available in appendix \ref{sec:fillers}. Fillers were not limited to the four main verbs of the experimental item, but did always follow the same pattern of *had* followed by a past participle. The past participle was always one of the four used for experimental item (*intended*, *decided*, *planned*, and *wanted*), or one of these additional four: *forgotten*, *remembered*, *meant*, or *needed*, with each of the 8 past participles being used twice in the +PP fillers and twice in the -PP fillers, for a total of 4 times each.

### Length

Length was tightly controlled across items. For experimental items, all sentences were between 66 and 75 characters long, and between 13 and 15 words long. The length never varied across the &plusmn;Q condition. Across the &plusmn;GP condition there was a maximum length difference of one character. Two items varied in word length across &plusmn; by one word. For all length variations (word and character), an equal number were longer in the +GP condition as in the -GP condition. They ranged from 18 to 22 syllables.

Control over filler length was slightly less stringent. They ranged from 63 to 79 characters and 12 to 14 words. 

## Experimental groups and order of items

No participant saw more than one version of each sentence, and each participant saw one version of every sentence. Each participant saw the same number of each type of sentence: 4 garden path declaratives, 4 garden path interrogatives, 4 non-garden path declaratives and 4 non-garden path interrogatives. The experimental item were presented in pseudo-random order, interspersed with 1 to 3 fillers and with two experimental items never occurring in the same version twice in a row (e.g. after declarative garden path, the next experimental item was never also a declarative garden path).

The four versions of the experimental sentences resulted in four groups. A split-half ordering (where the first 24 of the items presented to one group was the second 24 presented to the other) resulted in 2 versions for each group, and so there were 8 groups in total.

## Inter-reading time (IRT) measurement

Subjects were asked to read each sentence twice, once with no preview at all (reading 1, a cold reading), and then again after unlimited preview (reading 2, a previewed reading). Inter-reading time (IRT) is a measure of the amount of time between when a subject stops speaking after a cold reading and when they begin speaking for a previewed reading.



IRT was measured using a Python script and Google's WebRTC Voice Activity Detection (VAD) over 44.1kHz WAV files down-sampled to 8kHz via SOX[^upsamp]. This VAD system uses Gaussian Mixture Models to make probabilistic decisions on whether a given audio frame is speech or noise (see @gmm1 for a complete explanation). Google's implementation takes one parameter, which they call aggressiveness: a 4-tier setting for the level of confidence necessary to call a given frame speech. I call this "rejection rate", where a higher rejection rate means that the model requires a high level of confidence before assuming a frame is speech, i.e. it is more likely to label something noise than speech. The implementation codes this setting as 0-3, where 0 is the most lenient (most likely to label a frame as speech) and 3 is the most stringent (most likely to label a frame as noise).

[^upsamp]: Google's VAD API only accepts WAV files with sample rates that are a multiple of 8kHz. It ultimately down-samples all files to 8kHz, regardless of the input rate.

The recordings vary in the volume of the speaker's voice and the amount of background noise present. An algorithm was constructed to allow for the most stringent measurement of the least modified data that gave plausible measurements. Specifically, each file was measured using the highest possible rejection rate for the VAD algorithm and no modification of the file. If the timings detected were not plausible, the timings were re-measured with the same rejection rate, but after the recording had undergone a 200Hz high-pass filter[^alg] (HPF). If that still failed, a 400Hz HPF was used. After a further failure, the rejection rate for the VAD was lowered, and the whole thing was tried again (0, 200Hz, 400Hz); and that process was itself repeated until the lowest possible rejection rate was tried of the four possible settings. 

A plausible set of measurements had to meet the following criteria:

*Utterance length:* An utterance length between 2s and 10s, where utterance timing is the longest contiguous span in the recording that VAD reports as phonation, with breaks in phonation of less than 1s not breaking contiguity (@goldman1961-pa found that a large majority (82.5 to 87%) of pauses in fluent speech are less than 1s). Stimuli range from 18-22 syllables in length. If we assume a speech rate of 3 to 7 syllables per second [@jacewicz2010-sr] we would expect utterances between 2.5s and 7.3s. Conservative thresholds higher and lower than the expected were used, especially on the higher end, to allow for any difficulties processing or fluency that might have lead to longer reading times.

*Minimum leading silence:* A leading silence ("delay") of more than 120ms. Even a very fast human reaction time should not permit a delay shorter than 120ms, so a shorter delay likely means something went wrong with the procedure and the participant is already speaking before the sentence is displayed.

*Maximum edge silence:* A maximum trailing and leading silence length of less than 95% of the file's length was also used, in order to filter out recordings that do not represent a valid trial. Very long silences less than this very conservative threshold that impact the IRT are dealt with in the data clean up rather than via phonation detection, as described in the results section of this paper (section \ref{sec:irtDis}).

With 32 participants reading 48 items (experimental and filler) twice each, there are an expected number of 3072 recordings; due to technical issues at the time of data collection, 71 recordings are missing. Of the 3001 recordings subjected to this treatment, 2976 resulted in plausible timings. For those that were successful, the breakdown of HPF and rejection rate used is reported in Table \@ref(tab:metable). A further 9 were set by hand, resulting in a total of 2985 recordings.

[^alg]: The exact algorithm is available on [github](https://gist.github.com/moui72/4ebc4eb8f69eb9fdb1cab160ce299675) (URL: [bit.ly/2uMrcrG](https://bit.ly/2uMrcrG))

<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:metable)VAD rejection rate and high pass filter (HPF) values</caption>
 <thead>
  <tr>
   <th style="text-align:left;">   </th>
   <th style="text-align:right;"> No HPF </th>
   <th style="text-align:right;"> HPF at 200Hz </th>
   <th style="text-align:right;"> HPF at 400Hz </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> Lowest VAD rejection rate </td>
   <td style="text-align:right;"> 0 </td>
   <td style="text-align:right;"> 0 </td>
   <td style="text-align:right;"> 1 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> ... </td>
   <td style="text-align:right;"> 2 </td>
   <td style="text-align:right;"> 0 </td>
   <td style="text-align:right;"> 1 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> ... </td>
   <td style="text-align:right;"> 392 </td>
   <td style="text-align:right;"> 37 </td>
   <td style="text-align:right;"> 0 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Highest VAD rejection rate </td>
   <td style="text-align:right;"> 1380 </td>
   <td style="text-align:right;"> 1159 </td>
   <td style="text-align:right;"> 4 </td>
  </tr>
</tbody>
</table>

## Timing measurement reliability
```
NOTE TO DI:

Hand measurement is not yet completed.
```
Timings were collected by hand for 768 recordings (25.6%). Human measured timings were within 100ms of the VAD-measured timings in `??`% of cases.


## Prosodic judgments

A trained linguist informant naive to the research being conducted listened to recordings and reported the presence or absence of breaks in certain regions of the sentence, as well as several other judgments. She was instructed to familiarize herself with a speaker's speech patterns before rating any recordings by listening to 6 filler item recordings from that speaker. She was given a diagram of the sentences as in table \ref{tab:reg}, as well as full plain-text lists of all items.

<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:reg)Sentence region labels</caption>
 <thead>
  <tr>
   <th style="text-align:left;"> SUBJ </th>
   <th style="text-align:left;">   </th>
   <th style="text-align:left;"> V </th>
   <th style="text-align:left;">   </th>
   <th style="text-align:left;"> OBJ </th>
   <th style="text-align:left;"> PP1 </th>
   <th style="text-align:left;"> PP2 </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> He </td>
   <td style="text-align:left;"> had </td>
   <td style="text-align:left;"> meant </td>
   <td style="text-align:left;"> to stick ||$_{V}$ </td>
   <td style="text-align:left;"> the pencil case ||$_{OBJ}$ </td>
   <td style="text-align:left;"> in the cabinet ||$_{PP1}$ </td>
   <td style="text-align:left;"> into his book bag. </td>
  </tr>
  <tr>
   <td style="text-align:left;"> NP$_{SUBJ}$ </td>
   <td style="text-align:left;"> AUX </td>
   <td style="text-align:left;"> V$_1$ </td>
   <td style="text-align:left;"> V$_2$ </td>
   <td style="text-align:left;"> NP$_{OBJ}$ </td>
   <td style="text-align:left;"> PP$_1$ </td>
   <td style="text-align:left;"> PP$_2$ </td>
  </tr>
</tbody>
</table>

She was asked to report on whether or not she heard a prosodic boundary directly after the region labeled **V**, directly after the region labeled **OBJ**, and directly after the region labeled **PP1**. The following definition of prosodic break was provided:

>Please work with the assumption that “prosodic boundary” in what follows is any subset of the following features, clustered in such a way as to trigger your intuition that a new prosodic element (of any size) is beginning: pitch change, volume change, segmental lengthening, or pause.

The judgments requested also included whether or not the speaker struggled, where that struggle began, whether or not the speaker used question intonation, and which break(s) were stronger or more prominent than which other break(s). 

Detailed instructions on the order in which items should be listened to, both within speaker and across speakers, were also provided. The result was that she never listened to both readings of a sentence in sequence; she never listened to two reading 1 versions of different sentences in sequence; and she never listened to the sentences in the same order for a given participant as she did for the previous one.

Details on the instructions given and the judgments collected can be found in the appendices (\ref{sec:RA}).

### Reliability

A second trained linguist repeated the task over 128 recordings selected from 8 participants (two from each group, one per ordering). Even number experimental items were used from 4 participants, and odd numbered from the other 4. There were 8 recordings missing from the 128 selected, so the reliability task resulted in judgments over 120 recordings. The first informant also blindly re-rated those 120, with the recording name obscured and instructions not to revisit her original ratings. Reliability scores (percent of recordings agreed upon) are reported in table \ref{tab:validity}.



<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:validity)Inter and intra-rater agreement with Cohen's Kappa</caption>
 <thead>
<tr>
<th style="border-bottom:hidden" colspan="1"></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="3"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Breaks</div></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Break strength</div></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Struggle</div></th>
<th style="border-bottom:hidden" colspan="1"></th>
</tr>
  <tr>
   <th style="text-align:center;">   </th>
   <th style="text-align:center;"> V </th>
   <th style="text-align:center;"> OBJ </th>
   <th style="text-align:center;"> PP1 </th>
   <th style="text-align:center;"> STRONGEST </th>
   <th style="text-align:center;"> WEAKEST </th>
   <th style="text-align:center;"> STRUGGLED </th>
   <th style="text-align:center;"> START REGION </th>
   <th style="text-align:center;"> FINAL RISE </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:center;font-weight: bold;vertical-align: middle !important;" rowspan="3"> Inter-rater </td>
   <td style="text-align:center;"> 50.0% </td>
   <td style="text-align:center;"> 65.0% </td>
   <td style="text-align:center;"> 78.3% </td>
   <td style="text-align:center;"> 54.2% </td>
   <td style="text-align:center;"> 23.3% </td>
   <td style="text-align:center;"> 85.0% </td>
   <td style="text-align:center;"> 80.0% </td>
   <td style="text-align:center;"> 95.8% </td>
  </tr>
  <tr>
   
   <td style="text-align:center;"> K = 0.03 </td>
   <td style="text-align:center;"> K = 0.17** </td>
   <td style="text-align:center;"> K = 0.09 . </td>
   <td style="text-align:center;"> K = 0.25*** </td>
   <td style="text-align:center;"> K = 0.00 </td>
   <td style="text-align:center;"> K = 0.43*** </td>
   <td style="text-align:center;"> K = 0.27*** </td>
   <td style="text-align:center;"> K = 0.90*** </td>
  </tr>
  <tr>
   
   <td style="text-align:center;"> (z = 0.63) </td>
   <td style="text-align:center;"> (z = 2.61) </td>
   <td style="text-align:center;"> (z = 1.86) </td>
   <td style="text-align:center;"> (z = 3.99) </td>
   <td style="text-align:center;"> (z = 0.06) </td>
   <td style="text-align:center;"> (z = 5.23) </td>
   <td style="text-align:center;"> (z = 4.80) </td>
   <td style="text-align:center;"> (z = 9.88) </td>
  </tr>
  <tr>
   <td style="text-align:center;font-weight: bold;vertical-align: middle !important;" rowspan="3"> Intra-rater </td>
   <td style="text-align:center;"> 94.2% </td>
   <td style="text-align:center;"> 77.5% </td>
   <td style="text-align:center;"> 85.0% </td>
   <td style="text-align:center;"> 72.5% </td>
   <td style="text-align:center;"> 61.7% </td>
   <td style="text-align:center;"> 92.5% </td>
   <td style="text-align:center;"> 92.5% </td>
   <td style="text-align:center;"> 95.8% </td>
  </tr>
  <tr>
   
   <td style="text-align:center;"> K = 0.34*** </td>
   <td style="text-align:center;"> K = 0.52*** </td>
   <td style="text-align:center;"> K = 0.52*** </td>
   <td style="text-align:center;"> K = 0.44*** </td>
   <td style="text-align:center;"> K = 0.38*** </td>
   <td style="text-align:center;"> K = 0.60*** </td>
   <td style="text-align:center;"> K = 0.58*** </td>
   <td style="text-align:center;"> K = 0.90*** </td>
  </tr>
  <tr>
   
   <td style="text-align:center;"> (z = 4.22) </td>
   <td style="text-align:center;"> (z = 5.73) </td>
   <td style="text-align:center;"> (z = 5.82) </td>
   <td style="text-align:center;"> (z = 5.70) </td>
   <td style="text-align:center;"> (z = 6.08) </td>
   <td style="text-align:center;"> (z = 6.62) </td>
   <td style="text-align:center;"> (z = 7.57) </td>
   <td style="text-align:center;"> (z = 9.95) </td>
  </tr>
</tbody>
<tfoot>
<tr><td style="padding: 0; border: 0;" colspan="100%"><span style="font-style: italic;">Note: </span></td></tr>
<tr><td style="padding: 0; border: 0;" colspan="100%">
<sup></sup> *** p &lt; 0.001; ** p &lt; 0.01; * p &lt; 0.05, . p &lt; 0.1</td></tr>
</tfoot>
</table>

The lower intra-rater agreement for relative break strength was likely a result of a methodological issue: it was possible to report the same pattern, e.g. a pattern where a PP1 break is stronger than an OBJ break, by either giving the response "PP1" for strongest break, and "OBJ" for weakest break; or, "PP1" for strongest and "NONE" for weakest; or, "NONE" for strongest and "OBJ" for weakest. While the instructions to the rater requested full verbosity, it's likely that inconsistencies occurred for these cases.

The same inconsistencies would have hurt inter-rater agreement for strongest/weakest also. A further contributing issue for inter-rater agreement of those two judgments stems from the poor agreement on the presence of the verb break. When the raters don't agree about the presence of a break, that disagreement is magnified for the judgement of the relative strength of breaks.

