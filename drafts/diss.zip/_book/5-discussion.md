
# Discussion

This section will go through the motivating questions behind this study and discuss the extent to which those questions are answered, or not. It will discuss the issues that may have lead to some results that were disatisfying and how to correc them for futuer work. It will then go on to present further questions and propose further studies to explore those new questions and the ones left unanswered here.

## The hypotheses {#discHyp}

```
TODO
Go over each hypothesis and discuss its support or lack thereof from the data
```
  (@hypa) *Hypothesis 1* \hfill\linebreak
  High attachment of PP2 is prosodically marked by a boundary tone between PP1 and and PP2.

  (@hypb) *Hypothesis 2* \linebreak
  A cold reading (no preview) of a GP sentence will exhibit less natural prosody (more hesitation at and after the disambiguating region) than:
    * A cold reading of a non-GP sentence.
    * A previewed reading of a GP sentence.

  (@hypd) *Hypothesis 3* \linebreak
  A cold reading of a garden-path sentence will more often be produced with prosodic structure that represents an implausible or ungrammatical parse of the string (low attachment of PP2), whereas a previewed reading sentence will more often be pronounced with the prosodic structure that represents the intended parse (high attachment of PP2).

  (@hype) *Hypothesis 4* \linebreak
  A cold reading (no preview) of a declarative GP sentence will exhibit less natural prosody (more hesitation at and after the disambiguating region) and be more likely to be produced with  prosodic structure that represents an implausible or ungrammatical parse of the string than a cold reading of an interrogative GP sentence.
  
## Behavioral evidence for the intuition

Ultimately the data here are unable to provide a clear answer to whether or not IRT represents a behavioral correlate of the intuition that PP-attachment garden paths are rendered easier to parse when presented as polar questions. While the mean IRT by condition shows a difference of 0.04s in the direction predicted by the intuition, this is a rather small difference when the grand mean is 6.6s. Mixed-effect regression analyses were not able to detect stastical significance of the interaction between interogativity and &plusmn;GP. That said, it was also not clear that a model without the interaction was a better fit than one with it (Full model AIC = 9103.5; Non-interaction model AIC = 9101.6; &Chi;^2^ = 0.0352; p > 0.8). Ultimately, it seems likely that the size of the effect, if any, is simply too small to be detected without a huge amount of data. This does not, of course, negate the intuition; it simply means that we have not yet found a behavior that can be said with any certainty to correspond to that intuition.

There are a number of issues that might be preventing the observation of behavior that confirms the intuition, and there are also possible explanations for why the intuition might exist without a behavior correlate. These issues are discussed in subsection \ref{sec:confound}.

## Explaining the intuition

A possible explanation for the intuitive effect of interogativity on parsing garden paths is provided in the work by @Bader1998-ts. Bader demonstrates that it is easier to recover a parse that “behave[s] alike prosodically” to a given failed parse, because the reanalysis does not require prosodic reconstruction and only the syntax needs to be repaired. In the case of the intuition this study is concerned with, this would mean that should sentences be more similar across the garden path vs. non-garden path condition in the interrogative than in the declarative, the intuitive reduction in difficulty of reanalysis would naturally follow. 

While the data presented above do not definitively show that the prosodic structure of questions is less different for questions than it is for declaratives, it also does not rule it out. Because there does not appear to be a one-to-one mapping of prosodic structure to syntactic structure in the recordings, one cannot make a clear-cut declaration of what a given sentence type looks like prosodically. Instead, we must observe the percentage of recordings for each version of the sentences that exhibit a given pattern. Recall table \ref{tab:r2combobreaksBycond}, repeated here as\ref{tab:combobr} for convenience.

<table class="table" style="margin-left: auto; margin-right: auto;">
<caption>(\#tab:combobr)Combined breaks % per condition in reading 2 only</caption>
 <thead>
<tr>
<th style="border-bottom:hidden" colspan="1"></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Non-garden path</div></th>
<th style="border-bottom:hidden; padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #ddd; padding-bottom: 5px; ">Garden path</div></th>
</tr>
  <tr>
   <th style="text-align:left;">   </th>
   <th style="text-align:center;"> D </th>
   <th style="text-align:center;"> Q </th>
   <th style="text-align:center;"> D </th>
   <th style="text-align:center;"> Q </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;font-weight: bold;"> Both </td>
   <td style="text-align:center;"> 54.1 </td>
   <td style="text-align:center;"> 43.0 </td>
   <td style="text-align:center;"> 72.1 </td>
   <td style="text-align:center;"> 71.7 </td>
  </tr>
  <tr>
   <td style="text-align:left;font-weight: bold;"> OBJ </td>
   <td style="text-align:center;"> 31.1 </td>
   <td style="text-align:center;"> 31.4 </td>
   <td style="text-align:center;"> 0.8 </td>
   <td style="text-align:center;"> 2.5 </td>
  </tr>
  <tr>
   <td style="text-align:left;font-weight: bold;"> PP1 </td>
   <td style="text-align:center;"> 14.8 </td>
   <td style="text-align:center;"> 25.6 </td>
   <td style="text-align:center;"> 27.0 </td>
   <td style="text-align:center;"> 25.8 </td>
  </tr>
</tbody>
</table>

While there is a larger drop in the number of utterances with both breaks from +GP to -GP for questions than for decaratives, the opposite is true for the pattern with a PP1 break by itself. There is an argument to be made that the OBJ break, which does not correspond to a change in syntactic branching direction for any version of the sentences, is a hesitation rather than a break, due to a moment of confusion or perhaps simply a need to breathe. 

> QUESTION FOR DCB/JDF: Should I include trees here to show the branching direction change?

To be more explicit, for this explanation to work, the prosodic structures in @dlo and @dhi would likely be the ones considered "correct" or most common for a the declarative versions. The symbol "||" is being used to represent a prominent prosodic break.

  (@dlo) *D+GP*: He had crammed [~OBJ~ the newspapers] [~PP1~ under the sofa] || [~PP2~ into the trashcan].
  (@dhi) *D-GP*: He had crammed [~OBJ~ the newspapers] under the sofa in the guestroom.

 The prosodic structure of @dhi does not mandate any major break, because there is no change in syntactic branching directory and no other reason to mandate a break there. That is, the PP1 break differentiates the two syntactic structures and signals the attachment site of PP2. 
 
For the interrogatives, though, this contrast is obscured by the need to apply a rising prosodic contour over the final nuclear accent in the sentence: i.e. PP2, resulting in not a change in syntactic branching direction, but a tonal change, which might sound very similar to a prosodic break. The symbol "//" indicates the start of the rising contour.

  (@qlo) *Q+GP*: Had he crammed [~OBJ~ the newspapers] [~PP1~ under the sofa] ||+// [~PP2~ into the trashcan]?
  (@qhi) *Q-GP*: Had he crammed [~OBJ~ the newspapers] [~PP1~ under the sofa]    // [~PP2~ in the guestroom]?

The critical issue here is that in (@qhi), the absence of a syntactically-motivated break is hidden by the juncture created by the start of the final-rising contour of a question. 

If the PP1 break is treated as the main indicator of the prosodic structure, then the larger difference across &plusmn;GP for declaratives (12.2%) than for interrogatives (0.2%) does indeed, though perhaps weakly, leave open the door for the @Bader1998-ts style explanation of the intuition.

## Confounds {#confound}

A major roadblock to the success of the methodology here reported is that the region of the sentence where the critical prosodic difference between +GP and -GP sentences lies is the same region where disambiguation occurs for the +GP sentences. 
Some weaknesses in the data as they are leave need for future studies and  methodological improvements. A major issue is the difficulty in differentiating between "true" prosodic breaks and hesitations or breathing pauses. As table \ref(tab:combobr) and  the reliability data reported earlier in this paper illustrates, a linguistically trained judge will not necessarily be able to distinguish between prosodic breaks and hesitations, and will not necessarily agree with another linguistically trained judge on the relative prominence of breaks and hesitations within a recording. 

```
TODO

Expand discussion of hesitation vs. true prosodic break

Discuss further issues, e.g.

  * Over disambiguation (into, onto)
  * Disregard of instructions (naivety of procedure)
  * Ways to improve for a similar future study
    * Follow-up task to check understanding and interpretation of the sentence
    * Improve IRT accuracy by anticipating the participant’s desire to study slide 1 and either forcing it to disappear or else assuming that to be their study time.
```

## Areas for further study

The study just reported has not provided adequately convincing evidence that the inuition can or can not be explained entirely by the prosodic differences between questions and declaratives. Look at the same phenomenon in *embedded* questions vs. embedded declarative clauses, where prosody would not be at play. For example:

  (@embed_qgp) *Q +GP:* He asked her if she crammed the old newspapers under the couch in the wastebasket.
  (@embed_qct) *Q -GP:* He asked her if she crammed the old newspapers under the couch in the guestroom.  
  
  (@embed_dgp) *D +GP:* She told him that she crammed the old newspapers under the couch in the wastebasket.
  (@embed_dct) *D -GP:* She told him that she crammed the old newspapers under the couch in the guestroom.

These stimuli could be used in a behavioral (e.g. IRT-based), ERP or eye-tracking based study.

ERP-based study: check for Closure Positive Shift (CPS) at PP attachment sites; check for P600/N400 at site of disambiguation. CPS should reveal the tree being parsed for each condition; higher frequency and larger amplitude of P600/N400 across the GP condition in declaratives vs. interrogatives would illustrate the intuitive observation.

Eye-tracking: more regressions and longer reading time across the GP condition in declaratives vs. interrogatives would illustrate the intuitive observation.

