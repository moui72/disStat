---
bibliography: refs.bib
biblio-style: "apalike"
---
<!--
%Dissertation introduction
%This is the first content section
%Previous section: Front matter
%Following section: Background
-->
# Introduction

Before the details of the current research can be outlined, it&apos;s first necessary to explain some of the terms and mechanisms involved. Most critically, it&apos;s necessary to be clear on what a garden path is, and what causes the phenomena.

## What is a garden path?
The occurrence of garden-path (GP) effects are generally attributed to a clash between structure-first parsing strategies, e.g. @Frazier1979-pb's *Minimal Attachment*, and the actual intended structure of the sentence in question.

\BeginKnitrBlock{definition}\iffalse{-91-77-105-110-105-109-97-108-32-65-116-116-97-99-104-109-101-110-116-93-}\fi{}<div class="definition"><span class="definition" id="def:MinAtt"><strong>(\#def:MinAtt)  \iffalse (Minimal Attachment) \fi{} </strong></span>Attach incoming material into the phrase-marker being constructed using the fewest nodes consistent with the well-formedness rules of the language under analysis [@Frazier1979-pb]
</div>\EndKnitrBlock{definition}

If we assume that the parser builds structure by following these types of constraints or rules in a programmatic way, without concern for meaning, it&apos;s easy to see how one might end up with a parse that denotes an implausible situation, or even an ungrammatical sentence. An example is the commonly studied garden path sentence, &ldquo;The horse raced past the barn fell,&rdquo; [@bever1970]. Here, the initial parse incorrectly assumes that the matrix subject is the unmodified NP the horse, per *Minimal Attachment*, and takes the matrix verb to be raced, as in the sentence, &ldquo;The horse raced past the finish line.&rdquo;


(@hbf) The horse raced past the barn fell [@bever1970]
    a) [~S~ [~NP~ The horse] [~VP~ raced past the barn]] &emsp; ??? &emsp; [~VP~ fell]
    b) [~S~ [~NP~ The horse raced past the barn] [~VP~  fell]]


The attempted parse represented in structure (@hbf) crashes, as it isn"t possible to incorporate the final word fell in a grammatical way. In order to obtain the grammatical parse, (@hbf b) where the matrix subject is the horse raced past the barn, almost the entire structure of (@hbf a) must be discarded. The subject is not the horse, and the main verb is not raced. Rather, the subject is a noun phrase (NP) containing a reduced relative clause raced past the barn. Only after remediation can fell be properly incorporated as the matrix verb. This finally results in a grammatical sentence, with a structure comparable to, "The horse (that was) raced past the barn was hungry." Garden-path effects can result any time the assumptions made by the parser clash with the actual structure of a sentence. 

## PP-attachment garden paths

The type of garden-path sentence that this study is concerned with centers around the temporarily ambiguous attachment sites for a prepositional phrase (PP). Consider:

(@cramGPy) He had planned to cram the paperwork [~PP1~ in the drawer] [~PP2~ into his briefcase].

(@cramGPn) He had planned to cram the paperwork [~PP1~ in the drawer] [~PP2~ of his filing cabinet].

The sentences in (@cramGPy) and (@cramGPn) contain a temporary ambiguity with regard to the attachment site of in the drawer (PP1). It can either attach high, as an argument of the verb (i.e., the paperwork is being crammed in the drawer), or else low, as a modifier of the direct object (i.e. the paperwork in the drawer is being crammed into his briefcase). Sentence (@cramGPy) differs from (@cramGPn) in the ultimate resolution of that ambiguity, although in both cases disambiguation is triggered by the preposition heading the second PP, PP2 (into/of).
In (@cramGPy), PP1 must ultimately attach high, as the locative argument of the verb, in order for a plausible parse to be obtained. This is likely to cause some difficulty for the reader or listener of the sentence, if structure-first parsing strategies like *Minimal Attachment* are obeyed. The parser will have attached PP1 as the verb"s locative argument, not knowing PP2 was to come. The resulting parse crashes, because with PP1 attached high, PP2 has nowhere to attach but as a modifier of the noun in PP1 (\*[~NP~ the drawer into his briefcase]), or else as a modifier of the verb/sentence (*[~VP~ he did so into his briefcase]). The preference for VP attachment of PP1 in these kinds of sentences is supported by experimental data in studies from @raynerEtAl1983, @cliftonEtAl1991 and Schutz and Gibson (1999). 

The other sentence, (@cramGPn), should not represent any difficulty. The ambiguity is resolved such that PP1 can, and in fact must, attach high, since the subsequent PP of her filing cabinet (PP2) cannot plausibly attach as a sentential modifier, nor a verbal argument or modifier, and the sentence is incomplete without a destination of the cram action. By examining these sentences, the study proposed aims to expand understanding of human sentence processing in general, and specifically the relationship between syntactic structure and prosodic structure. Further, this will explore any contrast there might be in the impact of declarative and interrogative contexts on parsing, which has been under studied.

## An observation

These attachment ambiguities which are difficult to parse in the declarative, appear to be less difficult to parse when presented in yes-no interrogative context. Consider again the somewhat difficult to process sentence in (@cramGPy), repeated below as (@dec) for convenience.

  (@dec) He had planned to cram the paperwork [~PP1~ in the drawer] [~PP2~ into his  briefcase].

The mechanics of this garden path are discussed in section \ref{sec:mech}. The point to consider here is that, according to the intuition of many native speakers of American English, the difficulty of (@dec) is at least somewhat lessened in (@intr):

  (@intr) Had he planned to cram the paperwork [~PP1~ in the drawer] [~PP2~ into his briefcase]?

That is, while both sentences contain a temporary ambiguity for the attachment of PPs occurring in string-linear sequence at the end of an utterance, it is more likely in (@intr) that a listener or reader will come away with a plausible interpretation. This study explores the factors involved in why that is, and seeks to uncover a behavioral correlate of this intuition. If the existence and mechanics of this effect can be pinned down, it will lend insight into what information the parser has access to when making decisions, or when repairing broken parses. This initial observation reveals a robust program of research with many interwoven questions. 

One of the many questions is: can speaker behavior be shown to reflect the intuition? To say it another way, is there some behavior that is correlated with the reduction in difficulty of parsing PP-attachment garden paths that can be measured? Peckenpaugh (2016) represents one attempt to find such a correlate, and this paper continues that search.

One might also ask what property or properties of polar questions might lead to an easier parsing of garden paths, or at least to the perception that they are easier to parse as polar questions than as declaratives. Because there are minimal differences between the polar question and declarative version of a given sentence, it is fairly easy to assume that the cause lies in one of two domains: the prosodic changes triggered by the use of question intonation, or the pragmatic and semantic properties that are not shared across the versions. 

An obvious reflex of the former possibility is another question: how are the various versions of these sentences actually pronounced? This question is deceptively difficult to answer; the reported study seeks to answer it, but while the recordings collected provide some insight, more work is likely needed to satisfactorily provide an answer.

Likewise, the latter possibility leads one to wonder: what are the semantic and pragmatic differences between a polar question and its declarative counterpart? This question can be approach in a more theoretical way, and has been to some degree in the literature. That said, it remains to be determined how those properties could lead to an easier parsing process, and whether or not a satisfactory explanation for the intuition at large can be pulled from these differences. 
