
<!-- Background on prosody and parsing -->
<!-- This is the second content section -->
<!-- Previous section: introduction -->
<!-- Following section: methodology -->
# Background

This section goes over evidence supporting the claim that prosody can impact parsing decisions, even in silent reading.

## Can prosody affect parsing?
<!-- TODO Lehiste (1973) -->
<!-- DONE Kjelgaard & Speer (1999) -->
<!-- TODO Deniz and Fodor (2016) -->
A number of studies have shown that in listening to speech, prosodic cues appear to help reduce the frequency with which incorrect parsing (i.e. a garden path) occurs. For example, @Kjelgaard1999-xd conducted a study using digital manipulation of  recorded speech to create three versions of sentences containing a garden path temporary ambiguity (discussed above). They recorded speakers saying sentences with natural prosody, such as the following pair:

  (@ec) [When Roger leaves] the house is dark. (Early closure)
  (@lc)	[When Roger leaves the house] it&apos;s dark. (Late closure)
  
They then cross-spliced these together to make several versions. One version had prosodic cues which cooperated with the intended reading of the sentence; another attempted to have &ldquo;neutral&rdquo; prosody; and the third used intentionally misleading prosody. The initial fragment of each was then presented to participants (the portion from the beginning of the sentence to the word house in (@ec - @lc) and they were asked to agree or disagree with whether a visually presented word, either *is* or *it&apos;s* was likely to be the next word in the sentence. Participants gave more accurate and speedier judgements when the prosodic cues lined up with the correct parsing. The results of this study, as well as a growing body of literature, suggest that that prosodic information can (or perhaps must) be used by the parser in making processing decisions.

## Prosody in silent reading

The experiment presented in this paper is conducted using silent reading, and it is perhaps less intuitive to assume that prosody might play a role in the processing of silent reading compared to the processing of spoken utterances. Nonetheless, there is some evidence to support such an effect; as such, a positive result here is not a reason to dismiss the prosodic explanation for the effect, although it also can&apos;t support that explanation over others. Consider @Fodor2002-io analysis of relative clause attachment preference. This concerns sentences such as (@servant):

  (@servant) Someone shot the servant~N1~ of the actress~N2~ [~RC~ who was on the balcony].

The relative clause (RC) who was on the balcony can attach either locally (low, modifying N2), making it *the actress* who was *on the balcony*, or higher up (non-locally, modifying N1), so that we understand *the servant* to be the one who was *on the balcony*. In these sorts of sentences, @Cuetos1988-tm found a 60% preference for low attachment in English speakers, but only a 40% preference for low attachment in Spanish speakers. In apparent violation of the general preference for local attachment, recall *Minimal Attachment* (\@ref(def:MinAtt)), from @Frazier1979-pb, some languages, like French and Spanish (and Russian, but not Romanian or Brazilian Portuguese, so this is not a general feature of Romance languages), prefer to attach relative clauses higher, while others more often obey Late Closure (e.g., Swedish, Egyptian Arabic, and English). This non-local preference is weakened in cases where the ambiguous RC is short (one prosodic word). @Fodor2002-io asserts that these tendencies exist in both listening to spoken words (under conditions where a particular parse is not favored by the explicit prosody) and in silent reading.

Fodor notes that other researchers have shown the presence and absence of prosodic breaks to influence parsing decisions, and specifically that the presence of a prosodic break before the RC in sentences like (5) encourages high attachment. Fodor leverages this in order to explain the difference in RC attachment site tendency between languages. She argues that the phenomenon can be neatly account for by linking attachment site preference to the likelihood of a prosodic break before the RC. This difference in prosodic tendency, in turn, can be explained using a constraints-based approach. Consider Selkirk&apos;s [-@Selkirk1986-hc] alignment constraints:

\BeginKnitrBlock{definition}\iffalse{-91-71-101-110-101-114-97-108-105-115-101-100-32-65-108-105-103-110-109-101-110-116-93-}\fi{}<div class="definition"><span class="definition" id="def:galign"><strong>(\#def:galign)  \iffalse (Generalised Alignment) \fi{} </strong></span>
Align($\alpha$Cat, E; $\beta$Cat, E)

  a. Align (GCat, E; PCat, E)
  b. Align (PCat, E; GCat, E) 
  c. Align (PCat, E; PCat, E)
  
*GCat ranges over morphological and syntactic categories; PCat ranges over prosodic categories; E = Right or Left [@Selkirk1986-hc, p. 6]*
</div>\EndKnitrBlock{definition}

@Truckenbrodt1999-vd provides a prose-based formalization of the same idea. He describes what I will call *Align~R~* which can be easily generalized to described what I will call *Align~L~*, the same constraint except that it calls for aligning phrases at their left edges rather than their right edges.

  (@alignxp) **Align-XP/R** <br>
  For each XP there is a PP such that the right edge of the XP coincides with the right edge of the PP, where XP is a maximal projection and PP is a Phonological Phrase. This constraint represents the end based mapping assumption for Major Phonological Phrases in English, whose right end is supposed to align with the right end of Maximal Projections [@Truckenbrodt1999-vd, p. 223].

Essentially, Selkirk argues that relative ranking of alignment constraints for the left edge of phrases (*Align~L~*) with those for the right edge of phrases (*Align~R~*) can impact the distribution of prosodic breaks. These alignment constraints dictate that the edges of prosodic units (and thus the location of prosodic breaks) should align with the edges of syntactic constituents. Because the prosodic break that encourages high attachment is one which aligns with the left edge of the RC, postulating that *Align~L~* is ranked above *Align~R~* in languages like French that prefer high attachment can account for that preference (remember that a prosodic break in that place has been shown to encourage a high attachment interpretation). In languages where low attachment is preferred, we can assume that *Align~R~* is ranked higher, and thus a prosodic break is more likely to occur after the RC than before.

The same sort of argument can explain the difference in tendency between long and short RCs. Consider Selkirk&apos;s [-@selkirk2011-hp] *BinMin* defined below.

  (@binmin)	**BinMin($\phi$)** <br>
  A $\phi$ (phonological phrase) must consist of at least two $\omega$ (phonological words).  
  
If we assume, in Optimality Theoretic (Prince & Smolensky, 1993) terms, that a constraint like *BinMin* is ranked above *Align~L~*, then it seems quite reasonable to assume that  a prosodic break before a short RC (which would encourage high attachment) is much less likely than before a long RC. That is, when the RC is short, its left edge is prevented from aligning with the beginning of a prosodic phrase (it violates *Align~L~*) by the higher ranked BinMin. Longer RCs can have their left edge align with the start of a prosodic phrase, and thus can have the high-attachment encouraging prosodic break.

This analysis, of course, assumes the presence of prosodic cues, which are only overtly present in spoken utterances (punctuation aside). Given the elegance and explanatory power of this analysis, it seems reasonable to at least consider the further assumption necessary for it to also explain the phenomenon as it occurs in silent reading; which is that readers project prosodic structure over sentences even when they are read silently.

## Prosody of questions vs. declaratives

<!-- DONE What questions sound like -->
<!-- DONE Hedberg & Sosa (2002)  -->
<!-- DONE Informal pilot (Peckenpaugh 2018) -->
<!-- DONE What the prosodies of questions mean -->
<!-- DONE Hedberg et al. (2014/7) -->

In pursuing the possibility that it is the intonation and prosody of polar interrogatives which creates the intuitive contrast that this study investigates, we must consider what question intonation actually sounds like. It is generally agreed that in American English, the intonation of a polar (yes/no) question has the property of a final rise. Indeed, this has been confirmed in corpus studies such as @Hedberg2017-er who found that 79.8% of the 410 American English yes/no questions in their study (ten-minute phone conversations from  the CallHome Corpus of American English and  the Fisher English Corpus) had a &ldquo;low-rise nuclear contour&rdquo; (L\*H-H%, L\*H-&uarr;H%, or L\*L-H%)[^uar]. To briefly explain their ToBI notation, a tone T is either L for low or H for high; T\* is anchored to the stressed syllable, and T- and T% are boundary tones (intermediate phrase boundary and intonational phrase boundary respectively). See, e.g., *Guidleines for ToBI labeling* [@Beckman1997-eu] for a more thorough explanation of ToBI. An additional 10.7% of the @Hedberg2017-er data had a &ldquo;high-rise nuclear contour&rdquo; (the authors categorizes the following tunes as &ldquo;high-rise nuclear contours:&rdquo; H\*H-H%, or !H\*L-L%). That leaves only 9.5% spread across the other 5 categories (High-fall, Rise-fall, Low-fall, Fall-rise, and Level). Only 5.6% of the data showed a falling contour. According to the authors&apos; analyses, these contours occur on the final main stress of a sentence and thereafter. In the case of the types of sentences examined in the current study,that would result in a rising contour on the head noun of the final PP.

[^uar]: @Hedberg2017-er use &uarr; to indicate an upstep, which is not standardly transcribed with ToBI.

  (@rise) Did Jed cram the newspapers under the sofa in the	[~L\*H-H%~ guestroom].

The need to prepare for that rising tone might make a prosodic break before the PP more likely, and thus ease reanalysis or even encourage a different prosodic chunking which might encourage high attachment.

A brief informal survey found that most speakers maintain low tones on prior stresses, although some had a H tone on the subject noun. It also varied between speakers and between sentences as to whether there is a prosodic boundary (marked by a low tone and/or pause) immediately before the rise (after PP1) or not. 

The prosodic structures found in the data collected for the current study are discussed in \@ref(results-prosody).

## Syntactic structure of PP-attachment ambiguities {#mech}

As discussed in the introduction, this study is focused on the impact of sentence type (interrogative vs. declarative) in a particular sort of garden path. Specifically, it is concerned with garden path sentences containing a temporary ambiguity that centers on the attachment of prepositional phrases (PPs) occurring in string-linear sequence at the end of an utterance, e.g., “When he saw her, the nanny had seated the cranky little boy [~PP1~ on the swing] [~PP2~ in his stroller].”  Consider (13):

  (@trash) Jed crammed the newspapers under the sofa in the trashcan.
    
  a. \# … [~VP~ crammed [~NP~ the newspapers] [~PP1~ under [~NP~ the sofa [~PP2~ in the trashcan]]] 
  b. \checkmark … [~VP~ crammed [~NP~ the newspapers [~PP1~ under [~NP~ the sofa ]] [~PP2~ in the trashcan]]
    
\rightline{The \# symbol indicates a structure with an implausible reading}

In the case of this sort of garden path, *Minimal Attachment*, or some variation thereof, results in a structure where the first PP attaches to the verb phrase (VP) as an argument, i.e. [~VP~ V NP PP1], which leaves nowhere for the second PP to attach but as a modifier of the noun phrase (NP) inside PP1 (##[~PP1~ on [~NP~ the swing [~PP2~ in his stroller]]]). This initial parse (@trash~ ~a) is pragmatically implausible, as one does not generally find swings inside strollers. Reanalysis is required to bring about the correct parse (@trash~ ~b), where PP1 attaches as an NP modifier of the direct object [~VP~ V [~NP~ N PP1] …] which allows PP2 to attach as a VP argument, i.e. it is the cranky little boy on the swing who is being placed in the stroller. 

Note that *Minimal Attachment* as defined by Frazier (1979) is somewhat at odds with modern syntactic theory (cf. Chomsky 1995, p. 62). As originally postulated, it relies on a verb with multiple internal arguments incorporating each of those arguments as a sister (i.e. a ternary branching structure: [VP V NP PP]). With more modern theories where binary branching is obligatory, it becomes less clear that the VP attachment site for PP1 actually creates fewer nodes than the lower NP attachment site. Nonetheless, the preference for VP attachment in these kinds of sentences is there, be it due to *Minimal Attachment*, a preference for arguments over non-arguments, or whatever else:  see evidence from e.g. Rayner et al. (1983) and Clifton et al. (1991). I assume, following Frazier (1998) that it can be adequately described by reformulating *Minimal Attachment* to include a preference for argument relations over non-argument ones, or else through careful consideration of the syntactic structures involved and reformulation of *Minimal Attachment*. The precise definition of this parsing strategy is not a concern of this paper, but it is assumed to be at play.

## Predictions for the current study

This study is concerned with a number of issues. First: is attachment in any way encoded in the speech signal? I hypothesize, following e.g. Schafer et al. (2000), that we can use prosody to diagnose attachment site. Assume the following basic configuration:

  (@cfg) SUBJ V OBJ PP1 PP2

I suggest that high attachment of PP2 will be marked by a prosodic boundary between PP1 and PP2 (for discussion of what constitutes a prosodic boundary, see Streeter, 1978 and Salverda et al., 2003). Low attachment of PP2, on the other hand, will lack any substantial boundary marking.

```
*Question for Di:* (@hypa - @hype) are the hypothesis I wrote before running
the study, but they are not all really answered by the data I got. 
Is it dishonest to omit or revise them for this paper?
```

  (@hypa) *Hypothesis 1* \hfill\linebreak
  High attachment of PP2 is prosodically marked by a boundary tone between PP1 and and PP2.


The second issue: what factors impact immediate on-line parsing, and what factors only affect later, post-parse considerations? To address this, the study will employ the double reading paradigm of Fodor et al. (2018) (more on double reading in the methods section). For example, if first-pass parsing ignores semantic information, then implausible parses should be more frequent in cold readings (i.e. without preview) of a garden-path sentence than in a second reading of the same sentence.



  (@hypb) *Hypothesis 2* \linebreak
  A cold reading (no preview) of a GP sentence will exhibit less natural prosody (more hesitation at and after the disambiguating region) than:
    * A cold reading of a non-GP sentence.
    * A previewed reading of a GP sentence.

*Hypothesis 2* and *3* together make a third prediction: readers should struggle more on the cold reading of a GP sentence to obtain a plausible structure, and thus the appropriate prosody, than on a previewed reading.

  (@hypd) *Hypothesis 3* \linebreak
  A cold reading of a garden-path sentence will more often be produced with prosodic structure that represents an implausible or ungrammatical parse of the string (low attachment of PP2), whereas a previewed reading sentence will more often be pronounced with the prosodic structure that represents the intended parse (high attachment of PP2).

Note that hypothesis 3 can’t be applied in cases where the reader fails to successfully and fluently produce the sentence (which may sometimes happen, due to the GP effect).
Finally, I investigate an intuition originally discovered by Janet Dean Fodor and Dianne Bradley: that these GP sentences are not as difficult to parse when encountered in interrogative, as opposed to declarative, context.

  (@hype) *Hypothesis 4* \linebreak
  A cold reading (no preview) of a declarative GP sentence will exhibit less natural prosody (more hesitation at and after the disambiguating region) and be more likely to be produced with  prosodic structure that represents an implausible or ungrammatical parse of the string than a cold reading of an interrogative GP sentence.

In section \ref{sec:discHyp} I discuss to what extent these hypotheses are borne out.
  
