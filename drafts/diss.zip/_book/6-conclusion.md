# Conclusion

```
TODO
Expand on the below
```

Behavioral correlate of the intuition still might exist in IRT, but it remains to be fully supported (more data). Other possibilities exist (eye-tracking, ERP).

An explanation for the intuition still in the air, but the data seem to lean towards a non-prosodic account. Prosody-controlled embedded question work is the best next step.

Other interesting findings: interrogativity has a robust impact on IRT. Garden path condition has a robust impact on prosodic pattern.
